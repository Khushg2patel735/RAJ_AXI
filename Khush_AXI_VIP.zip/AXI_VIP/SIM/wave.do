onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /axi_tb_top/axi_mas_inf/ACLK
add wave -noupdate /axi_tb_top/axi_mas_inf/ARESETn
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWID
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWADDR
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWLEN
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWSIZE
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWBURST
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWVALID
add wave -noupdate -expand -group MAS_AW_CH /axi_tb_top/axi_mas_inf/AWREADY
add wave -noupdate -expand -group MAS_W_CH /axi_tb_top/axi_mas_inf/WID
add wave -noupdate -expand -group MAS_W_CH /axi_tb_top/axi_mas_inf/WDATA
add wave -noupdate -expand -group MAS_W_CH /axi_tb_top/axi_mas_inf/WSTRB
add wave -noupdate -expand -group MAS_W_CH /axi_tb_top/axi_mas_inf/WLAST
add wave -noupdate -expand -group MAS_W_CH /axi_tb_top/axi_mas_inf/WVALID
add wave -noupdate -expand -group MAS_W_CH /axi_tb_top/axi_mas_inf/WREADY
add wave -noupdate -expand -group MAS_B_CH /axi_tb_top/axi_mas_inf/BID
add wave -noupdate -expand -group MAS_B_CH /axi_tb_top/axi_mas_inf/BRESP
add wave -noupdate -expand -group MAS_B_CH /axi_tb_top/axi_mas_inf/BVALID
add wave -noupdate -expand -group MAS_B_CH /axi_tb_top/axi_mas_inf/BREADY
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARID
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARADDR
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARLEN
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARSIZE
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARBURST
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARVALID
add wave -noupdate -expand -group MAS_AR_CH /axi_tb_top/axi_mas_inf/ARREADY
add wave -noupdate -expand -group MAS_R_CH /axi_tb_top/axi_mas_inf/RID
add wave -noupdate -expand -group MAS_R_CH /axi_tb_top/axi_mas_inf/RDATA
add wave -noupdate -expand -group MAS_R_CH /axi_tb_top/axi_mas_inf/RRESP
add wave -noupdate -expand -group MAS_R_CH /axi_tb_top/axi_mas_inf/RLAST
add wave -noupdate -expand -group MAS_R_CH /axi_tb_top/axi_mas_inf/RVALID
add wave -noupdate -expand -group MAS_R_CH /axi_tb_top/axi_mas_inf/RREADY
add wave -noupdate /axi_tb_top/axi_slv_inf/ACLK
add wave -noupdate /axi_tb_top/axi_slv_inf/ARESETn
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWID
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWADDR
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWLEN
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWSIZE
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWBURST
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWVALID
add wave -noupdate -group SLV_AW_CH /axi_tb_top/axi_slv_inf/AWREADY
add wave -noupdate -group SLV_W_CH /axi_tb_top/axi_slv_inf/WID
add wave -noupdate -group SLV_W_CH /axi_tb_top/axi_slv_inf/WDATA
add wave -noupdate -group SLV_W_CH /axi_tb_top/axi_slv_inf/WSTRB
add wave -noupdate -group SLV_W_CH /axi_tb_top/axi_slv_inf/WLAST
add wave -noupdate -group SLV_W_CH /axi_tb_top/axi_slv_inf/WVALID
add wave -noupdate -group SLV_W_CH /axi_tb_top/axi_slv_inf/WREADY
add wave -noupdate -group SLV_B_CH /axi_tb_top/axi_slv_inf/BID
add wave -noupdate -group SLV_B_CH /axi_tb_top/axi_slv_inf/BRESP
add wave -noupdate -group SLV_B_CH /axi_tb_top/axi_slv_inf/BVALID
add wave -noupdate -group SLV_B_CH /axi_tb_top/axi_slv_inf/BREADY
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARID
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARADDR
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARLEN
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARSIZE
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARBURST
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARVALID
add wave -noupdate -group SLV_AR_CH /axi_tb_top/axi_slv_inf/ARREADY
add wave -noupdate -group SLV_R_CH /axi_tb_top/axi_slv_inf/RID
add wave -noupdate -group SLV_R_CH /axi_tb_top/axi_slv_inf/RDATA
add wave -noupdate -group SLV_R_CH /axi_tb_top/axi_slv_inf/RRESP
add wave -noupdate -group SLV_R_CH /axi_tb_top/axi_slv_inf/RLAST
add wave -noupdate -group SLV_R_CH /axi_tb_top/axi_slv_inf/RVALID
add wave -noupdate -group SLV_R_CH /axi_tb_top/axi_slv_inf/RREADY
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {125 ns} 0}
quietly wave cursor active 1
configure wave -namecolwidth 128
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ns} {299 ns}
