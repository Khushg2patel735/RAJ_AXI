//======================================================================
// File Name      : axi_base_vseqs.sv
// Module Name    : axi_base_vseqs
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-08-02 18:43:18
// Last Modified  : 2026-08-02 19:51:46
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_BASE_VSEQS_SV
`define AXI_BASE_VSEQS_SV

class axi_base_vseqs extends uvm_sequence #(uvm_sequence_item);
  
  `uvm_object_utils(axi_base_vseqs)
  

  	axi_mas_seq_item req;
  	axi_vseqr vseqr_h;
    
  function new(string name="");
    super.new(name);
  endfunction

  task pre_start();
    if(!$cast(vseqr_h,m_sequencer))
      `uvm_fatal("Casting","Castin fail");
  endtask
endclass
`endif

