//======================================================================
// File Name      : axi_env.sv
// Module Name    : axi_env
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 22:56:32
// Last Modified  : 2026-10-06 11:28:28
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_ENV_SV
`define AXI_ENV_SV
class axi_env extends uvm_env;
    `uvm_component_utils(axi_env)

    axi_mas_agent #(`MAS_ADDR_W, `MAS_DATA_W) mas_agent_h;
    axi_slv_agent #(`SLV_ADDR_W, `SLV_DATA_W) slv_agent_h;
    axi_vseqr vseqr_h;
    axi_env_config env_cfg_h;
    axi_mas_config mas_cfg_h;
    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

    function void build_phase(uvm_phase phase);

      env_cfg_h = axi_env_config::type_id::create("env_cfg_h");
      if(!uvm_config_db #(axi_env_config)::get(this,"","env_cfg_h",env_cfg_h))
          `uvm_error("ENV_CFG","Env config fail to get")

      mas_cfg_h = axi_mas_config::type_id::create("mas_cfg_h");
        mas_cfg_h.axi3_active = env_cfg_h.axi3_active;
        mas_cfg_h.pipe_drv_enb = env_cfg_h.pipe_drv_enb;
        mas_cfg_h.valid_toggle = env_cfg_h.valid_toggle;

      uvm_config_db #(axi_mas_config)::set(this,"mas_agent_h.drv_h","mas_cfg_h",mas_cfg_h);

      mas_agent_h = axi_mas_agent#(`MAS_ADDR_W, `MAS_DATA_W)::type_id::create("mas_agent_h",this);
      slv_agent_h = axi_slv_agent#(`SLV_ADDR_W, `SLV_DATA_W)::type_id::create("slv_agent_h",this);
      vseqr_h = axi_vseqr::type_id::create("vseq_h",this);
    $display("a=%0d,d=%0d",`MAS_ADDR_W, `MAS_DATA_W);
	endfunction

    function void connect_phase(uvm_phase phase);
      vseqr_h.mas_seqr_h = mas_agent_h.seqr_h;
      vseqr_h.slv_seqr_h = slv_agent_h.seqr_h;
    //  mas_agent_h.mon_h.ana_port.connect(sb_h.ana_imp1);
     // slv_agent_h.mon_h.ana_port.connect(sb_h.ana_imp2);
    
	endfunction
endclass
`endif

