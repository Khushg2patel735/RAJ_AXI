//======================================================================
// File Name      : axi_mas_inf.sv
// Module Name    : axi_mas_inf
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-28 17:13:55
// Last Modified  : 2026-09-16 14:00:35
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_INF_SV
`define AXI_MAS_INF_SV
interface axi_mas_inf #(parameter int ADDR_W = 32,
                    parameter int DATA_W = 32
                   )(input logic ACLK);

//Global signal
    logic                ARESETn;

//Write Channel
    //Write Address Channel
    logic [3:0]          AWID;
    logic [ADDR_W-1:0]   AWADDR;
    logic [7:0]          AWLEN;
    logic [2:0]          AWSIZE;
    logic [1:0]          AWBURST;
    logic                AWVALID;
    logic                AWREADY;

    //Write Data Channel
    logic [3:0]          WID;
    logic [DATA_W-1:0]   WDATA;
    logic [DATA_W/8-1:0] WSTRB;
    logic                WLAST;
    logic                WVALID;
    logic                WREADY;

    //Write Response Channel
    logic [3:0]          BID;
    logic [1:0]          BRESP;
    logic                BVALID;
    logic                BREADY;


//Read Channel
    //Read Address Channel
    logic [3:0]          ARID;
    logic [ADDR_W-1:0]   ARADDR;
    logic [7:0]          ARLEN;
    logic [2:0]          ARSIZE;
    logic [1:0]          ARBURST;
    logic                ARVALID;
    logic                ARREADY;

    //Read Data Channel
    logic [3:0]          RID;
    logic [DATA_W-1:0]   RDATA;
    logic [DATA_W/8-1:0] RRESP;
    logic                RLAST;
    logic                RVALID;
    logic                RREADY;


    clocking mas_drv_cb @(posedge ACLK);
        default input #1 output #1;

        output AWID,AWADDR,AWLEN,AWSIZE,AWBURST,AWVALID;
        input  AWREADY;

        output WID,WDATA,WSTRB,WLAST,WVALID;
        input  WREADY;

        input  BID,BRESP,BVALID;
        output BREADY;

        output ARID,ARADDR,ARLEN,ARSIZE,ARBURST,ARVALID;
        input  ARREADY;

        input  RID,RDATA,RRESP,RLAST,RVALID;
        output RREADY;
    endclocking

    clocking mas_mon_cb @(posedge ACLK);
        default input #1 output #1;

        input  AWID,AWADDR,AWLEN,AWSIZE,AWBURST,AWVALID;
        input  AWREADY;

        input  WID,WDATA,WSTRB,WLAST,WVALID;
        input  WREADY;

        input  BREADY;
        input  BID,BRESP,BVALID;

        input  ARID,ARADDR,ARLEN,ARSIZE,ARBURST,ARVALID;
        input  ARREADY;

        input  RID,RDATA,RRESP,RLAST,RVALID;
        input  RREADY;
    endclocking

    modport MAS_DRV_MP (clocking mas_drv_cb);
    modport MAS_MON_MP (clocking mas_mon_cb);
endinterface
`endif


