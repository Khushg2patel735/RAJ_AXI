//======================================================================
// File Name      : axi_vsqer.sv
// Module Name    : axi_vsqer
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-08-02 18:41:47
// Last Modified  : 2026-08-02 19:23:56
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_VSEQR_SV
`define AXI_VSEQR_SV
class axi_vseqr extends uvm_sequencer #(uvm_sequence_item);
  
  `uvm_component_utils(axi_vseqr)
  
  axi_mas_seqr mas_seqr_h;
  axi_slv_seqr slv_seqr_h;
 
  function new(string name="",uvm_component parent);
  	super.new(name,parent);
  endfunction
  
endclass
`endif
