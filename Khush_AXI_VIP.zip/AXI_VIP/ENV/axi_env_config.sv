//======================================================================
// File Name      : axi_env_config.sv
// Module Name    : axi_env_config
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-08-07 14:27:54
// Last Modified  : 2026-10-06 11:36:49
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_ENV_CONFIG_SV
`define AXI_ENV_CONFIG_SV
class axi_env_config extends uvm_object;

    function new(string name="");
        super.new(name);
    endfunction

    uvm_active_passive_enum axi3_active;
    uvm_active_passive_enum pipe_drv_enb;
    bit valid_toggle;

    `uvm_object_utils_begin(axi_env_config) 
            `uvm_field_enum(uvm_active_passive_enum,axi3_active,UVM_ALL_ON)
            `uvm_field_enum(uvm_active_passive_enum,pipe_drv_enb,UVM_ALL_ON)
            `uvm_field_int(valid_toggle,UVM_ALL_ON)
    `uvm_object_utils_end
endclass

`endif

