//======================================================================
// File Name      : axi_slv_seq_item.sv
// Module Name    : axi_slv_seq_item
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-09-16 12:39:43
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_SEQ_ITEM_SV
`define AXI_SLV_SEQ_ITEM_SV

class axi_slv_seq_item #(int ADDR_W = 32,
                         int DATA_W = 32) extends uvm_sequence_item;

    typedef enum {FIXED,
                  INCR,
                  WRAP} BURST_TYPE;

    typedef enum {WRITE,
                  READ,
                  SWR} TRANSFER_TYPE_E;

    rand TRANSFER_TYPE_E transfer_type;

    bit [3:0]          AWID;
    bit [ADDR_W-1:0]   AWADDR;
    bit [7:0]          AWLEN;
    bit [2:0]          AWSIZE;
    BURST_TYPE         AWBURST;

    bit [3:0]          WID;
    bit [DATA_W-1:0]   WDATA[];
    bit [DATA_W/8-1:0] WSTRB[];
    bit                WLAST;

    bit [3:0]          BID;
    bit [1:0]          BRESP;


    rand bit [3:0]          ARID;
    bit [ADDR_W-1:0]   ARADDR;
    bit [7:0]          ARLEN;
    bit [2:0]          ARSIZE;
    BURST_TYPE         ARBURST;

    rand bit [3:0]          RID;
    bit [DATA_W-1:0]   RDATA[];
    bit [1:0]          RRESP;
    bit                RLAST;

    int total_byte_trasfer = (1<<AWSIZE)*(AWLEN+1);
    bit [ADDR_W-1:0] lower_wrap_boundry = (AWADDR) - (AWADDR % total_byte_trasfer);
    bit [ADDR_W-1:0] upper_wrap_boundry = lower_wrap_boundry + total_byte_trasfer;
//    constraint AWLEN_LIMIT {AWLEN inside {1,3,7,15};}

    constraint ID_SIZE {RID == ARID;}
    constraint AWSIZE_RESTRICT {1<<AWSIZE <= DATA_W/8;}

	constraint WDATA_SIZE_C {soft WDATA.size == AWLEN + 1;}
	constraint STRB_SIZE_C {soft WSTRB.size == AWLEN + 1;}
	constraint RDATA_SIZE_C {soft RDATA.size == ARLEN + 1;}

    `uvm_object_param_utils_begin(axi_slv_seq_item#(ADDR_W,DATA_W))
    `uvm_field_int(AWID    , UVM_ALL_ON)
    `uvm_field_int(AWADDR  , UVM_ALL_ON)
    `uvm_field_int(AWLEN   , UVM_ALL_ON)
    `uvm_field_int(AWSIZE  , UVM_ALL_ON)
	`uvm_field_enum(BURST_TYPE, AWBURST, UVM_ALL_ON)
 
    `uvm_field_int(WID     , UVM_ALL_ON)
    `uvm_field_array_int(WDATA   , UVM_ALL_ON)
    `uvm_field_array_int(WSTRB   , UVM_ALL_ON)
    `uvm_field_int(WLAST   , UVM_ALL_ON)

    `uvm_field_int(BID     , UVM_ALL_ON)
    `uvm_field_int(BRESP   , UVM_ALL_ON)

    `uvm_field_int(ARID    , UVM_ALL_ON)
    `uvm_field_int(ARADDR  , UVM_ALL_ON)
    `uvm_field_int(ARLEN   , UVM_ALL_ON)
    `uvm_field_int(ARSIZE  , UVM_ALL_ON)
    `uvm_field_enum(BURST_TYPE, ARBURST, UVM_ALL_ON)
		
    `uvm_field_int(RID     , UVM_ALL_ON)
    `uvm_field_array_int(RDATA   , UVM_ALL_ON)
	`uvm_field_int(RRESP   , UVM_ALL_ON)
    `uvm_field_int(RLAST   , UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name="");
        super.new(name);
    endfunction
endclass
`endif
