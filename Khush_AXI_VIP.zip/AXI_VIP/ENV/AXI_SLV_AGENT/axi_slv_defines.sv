//======================================================================
// File Name      : axi_slv_defines.sv
// Module Name    : axi_slv_defines
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-23 09:56:51
// Last Modified  : 2026-08-02 19:59:35
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_DEFINES_SV
`define AXI_SLV_DEFINES_SV

`define SLV_DATA_W 32
`define SLV_ADDR_W 32
`define SLV_STRB_W `SLV_DATA_W/8

`endif


