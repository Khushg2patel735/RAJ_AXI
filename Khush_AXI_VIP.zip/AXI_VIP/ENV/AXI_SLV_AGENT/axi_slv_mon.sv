//======================================================================
// File Name      : axi_slv_mon.sv
// Module Name    : axi_slv_mon
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-10-05 14:43:09
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_MON_SV
`define AXI_SLV_MON_SV

class axi_slv_mon #(int ADDR_W = 32,
                    int DATA_W = 32) extends uvm_monitor;

    `uvm_component_param_utils(axi_slv_mon #(ADDR_W,DATA_W))

    virtual axi_slv_inf #(ADDR_W, DATA_W).SLV_MON_MP vinf;

    uvm_analysis_port #(axi_slv_seq_item #(ADDR_W,DATA_W)) req_collect_port;

    axi_slv_seq_item #(ADDR_W,DATA_W) trans_h[bit[3:0]];
    int beat_index[bit[3:0]];
    int beat;

    function new(string name="", uvm_component parent);
        super.new(name,parent);
        req_collect_port = new("req_collect_port",this);
    endfunction

    task run_phase(uvm_phase phase);
        fork
            sample_aw();
            sample_w();
            sample_ar();
        join
    endtask

    task sample_aw();
    forever begin
    bit [3:0] ID; // for the ID based out of order data management
        //wait (vinf.slv_mon_cb.AWVALID && vinf.slv_mon_cb.AWREADY);
        @(vinf.slv_mon_cb iff (vinf.slv_mon_cb.AWVALID && vinf.slv_mon_cb.AWREADY));
        ID = vinf.slv_mon_cb.AWID;
        trans_h[ID] = axi_slv_seq_item #(ADDR_W,DATA_W)::type_id::create($sformatf("trans_h[%0d]",ID));
        trans_h[ID].transfer_type = axi_slv_seq_item #(ADDR_W,DATA_W)::WRITE;
        trans_h[ID].AWID    = vinf.slv_mon_cb.AWID;
        trans_h[ID].AWADDR  = vinf.slv_mon_cb.AWADDR;
        trans_h[ID].AWLEN   = vinf.slv_mon_cb.AWLEN;
        trans_h[ID].AWSIZE  = vinf.slv_mon_cb.AWSIZE;
        trans_h[ID].AWBURST = vinf.slv_mon_cb.AWBURST;

        trans_h[ID].WDATA = new[trans_h[ID].AWLEN+1'b1];
        trans_h[ID].WSTRB = new[trans_h[ID].AWLEN+1'b1];
     beat_index[ID] = 0;
        `uvm_info("SLV_MON_AW_CH",
                $sformatf("[%0t] CH=AW L_ID=%0h AWID=%0h ADDR=%0h LEN=%0h",
                      $time,
                      ID,
                      trans_h[ID].AWID,
                      trans_h[ID].AWADDR,
                      trans_h[ID].AWLEN
                      ),
            UVM_MEDIUM)
    end
    endtask

    task sample_w();
    forever begin 
   bit [3:0] ID; // for the ID based out of order data management
    #10;
    wait(vinf.slv_mon_cb.WVALID && vinf.slv_mon_cb.WREADY);
   // @(vinf.slv_mon_cb);
//  @(vinf.slv_mon_cb iff (vinf.slv_mon_cb.WVALID && vinf.slv_mon_cb.WREADY));
        ID = vinf.slv_mon_cb.WID;
        if(!trans_h.exists(ID))
            `uvm_info("ID_ACCESS_NULL",$sformatf("WID = %0h received but not create so it reflect null reference access",ID),
                    UVM_MEDIUM)
        else begin
                   //     trans_h[ID] = axi_slv_seq_item #(ADDR_W,DATA_W)::type_id::create($sformatf("trans_h[%0d]",ID));
                   // @(vinf.slv_mon_cb);
                   //  wait (vinf.slv_mon_cb.WVALID && vinf.slv_mon_cb.WREADY);
                   //   foreach(trans_h[ID].WDATA[i])begin
            beat = beat_index[ID]; 
            trans_h[ID].WID    = vinf.slv_mon_cb.WID;
            trans_h[ID].WDATA[beat]  = vinf.slv_mon_cb.WDATA;
            trans_h[ID].WSTRB[beat]  = vinf.slv_mon_cb.WSTRB;
            trans_h[ID].WLAST  = vinf.slv_mon_cb.WLAST;
               `uvm_info("SLV_MON_W_CH",
                    $sformatf("[%0t] CH=DW L_ID=%0h WID=%0h BEATS=%0h DATA=%0h WLAST=%0h",
                            $time,
                            ID,
                            trans_h[ID].WID,
                            beat,
                            trans_h[ID].WDATA[beat],
                            trans_h[ID].WLAST),
                    UVM_MEDIUM)

            if(vinf.slv_mon_cb.WLAST)begin
                `uvm_info("SLV_MON_WLAST","WLAST assert",UVM_MEDIUM)
     req_collect_port.write(trans_h[ID]);
             beat_index[ID] = 0;
           //  beat_index.delete(ID);
                //trans_h.delete(ID);
            end
            else
                beat_index[ID]++;
      //  end
        end
    end
    endtask

    task sample_ar();
    forever begin
    bit [3:0] ID; // for the ID based out of order data management
        //wait (vinf.slv_mon_cb.ARVALID && vinf.slv_mon_cb.ARREADY);
        @(vinf.slv_mon_cb iff (vinf.slv_mon_cb.ARVALID && vinf.slv_mon_cb.ARREADY));
        ID = vinf.slv_mon_cb.ARID;
        trans_h[ID] = axi_slv_seq_item #(ADDR_W,DATA_W)::type_id::create($sformatf("trans_h[%0d]",ID));
        trans_h[ID].transfer_type = axi_slv_seq_item #(ADDR_W,DATA_W)::READ;
        trans_h[ID].ARID    = vinf.slv_mon_cb.ARID;
        trans_h[ID].ARADDR  = vinf.slv_mon_cb.ARADDR;
        trans_h[ID].ARLEN   = vinf.slv_mon_cb.ARLEN;
        trans_h[ID].ARSIZE  = vinf.slv_mon_cb.ARSIZE;
        trans_h[ID].ARBURST = vinf.slv_mon_cb.ARBURST;

        `uvm_info("SLV_MON_AR_CH",
                $sformatf("[%0t] CH=AR L_ID=%0h ARID=%0h ADDR=%0h LEN=%0h",
                      $time,
                      ID,
                      trans_h[ID].ARID,
                      trans_h[ID].ARADDR,
                      trans_h[ID].ARLEN
                      ),
            UVM_MEDIUM)

     req_collect_port.write(trans_h[ID]);
    end
    endtask

endclass
`endif




