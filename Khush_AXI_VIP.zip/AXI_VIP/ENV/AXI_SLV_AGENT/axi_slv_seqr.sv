//======================================================================
// File Name      : axi_slv_seqr.sv
// Module Name    : axi_slv_seqr
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-08-13 23:05:58
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_SEQR_SV
`define AXI_SLV_SEQR_SV

class axi_slv_seqr #(int ADDR_W = 32,
                     int DATA_W = 32) extends uvm_sequencer #(axi_slv_seq_item #(ADDR_W,DATA_W));

    `uvm_component_param_utils(axi_slv_seqr #(ADDR_W,DATA_W))

    uvm_analysis_export #(axi_slv_seq_item #(ADDR_W,DATA_W)) req_collect_export;
    uvm_analysis_imp #(axi_slv_seq_item#(ADDR_W,DATA_W), axi_slv_seqr#(ADDR_W,DATA_W)) analysis_imp;
    uvm_tlm_analysis_fifo #(axi_slv_seq_item #(ADDR_W,DATA_W)) req_item_fifo;
    function new(string name="", uvm_component parent);
        super.new(name,parent);
        req_collect_export = new("req_collect_export",this);
        analysis_imp = new("analysis_imp",this);
        req_item_fifo = new("req_item_fifo",this);
    endfunction

    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);
        req_collect_export.connect(req_item_fifo.analysis_export);
    endfunction
    
    function void write(axi_slv_seq_item #(ADDR_W,DATA_W) trans);

    `uvm_info("SEQR_RX",
        $sformatf("WRITE RECEIVED: ID=%0h ADDR=%0h LEN=%0d BURST=%0s",
                  trans.AWID,
                  trans.AWADDR,
                  trans.AWLEN,
                  trans.AWBURST),
        UVM_MEDIUM)

    foreach (trans.WDATA[i]) begin
      if(trans.WDATA[i] != 0) begin  
          `uvm_info("SEQR_W_DATA",
            $sformatf("W[%0d] = %0h  WSTRB=%0h",
                      i,
                      trans.WDATA[i],
                      trans.WSTRB[i]),
            UVM_MEDIUM)
    end
    else
        begin
          `uvm_info("SEQR_W_DATA_ZERO",
            $sformatf("W[%0d] = %0h  WSTRB=%0h",
                      i,
                      trans.WDATA[i],
                      trans.WSTRB[i]),
            UVM_MEDIUM)
    end
    end


endfunction
endclass
`endif

