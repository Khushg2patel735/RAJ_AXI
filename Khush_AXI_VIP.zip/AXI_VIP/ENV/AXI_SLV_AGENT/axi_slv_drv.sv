//======================================================================
// File Name      : axi_slv_drv.sv
// Module Name    : axi_slv_drv
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-10-06 23:14:11
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_DRV_SV
`define AXI_SLV_DRV_SV

class axi_slv_drv #(int ADDR_W = 32,
                    int DATA_W = 32) extends uvm_driver #(axi_slv_seq_item #(ADDR_W,DATA_W),axi_slv_seq_item #(ADDR_W,DATA_W));

    `uvm_component_param_utils(axi_slv_drv #(ADDR_W,DATA_W)) 
    
    virtual axi_slv_inf #(ADDR_W, DATA_W).SLV_DRV_MP vinf;

    //define a queue for each channel for each tranction to store the request for that channel.
    axi_slv_seq_item #(ADDR_W,DATA_W) addr_write_q [$];
    axi_slv_seq_item #(ADDR_W,DATA_W) data_write_q [$];
    axi_slv_seq_item #(ADDR_W,DATA_W) rsp_write_q [$];
    axi_slv_seq_item #(ADDR_W,DATA_W) addr_read_q [$];
    axi_slv_seq_item #(ADDR_W,DATA_W) data_read_q [$];

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction
    

    task run_phase(uvm_phase phase);
    fork 
        forever begin 
            seq_item_port.get_next_item(req);
//            seq_item_port.get(req);
                
        case(req.transfer_type)

        axi_slv_seq_item #(ADDR_W,DATA_W)::WRITE: begin
            rsp_write_q.push_back(req);
        end

        axi_slv_seq_item #(ADDR_W,DATA_W)::READ: begin
            data_read_q.push_back(req);
        end

        axi_slv_seq_item #(ADDR_W,DATA_W)::SWR: begin
            rsp_write_q.push_back(req);
            data_read_q.push_back(req);
        end

    endcase

              //  $cast(rsp,req.clone());//Clone the req trans into a new rsp trans. This creates a separate object having the same field values as the req
                //    rsp.set_id_info(req);
           // if (!pipe_drv_enb)
               // @(ev);
             //   `uvm_info("PIP_ENB",$sformatf("pipe_drv_enb = %0d",pipe_drv_enb),UVM_MEDIUM)
            seq_item_port.item_done();
        end
    join_none

    //5 individual channel
    fork 
    addr_write();
    data_write();
    rsp_write();
    addr_read();
    data_read();
    join_none
    endtask


    task addr_write();
    axi_slv_seq_item #(ADDR_W,DATA_W) trans;
    forever begin
        @(vinf.slv_drv_cb);
        vinf.slv_drv_cb.AWREADY <= 1;
    end
    endtask

    task data_write();
    axi_slv_seq_item #(ADDR_W,DATA_W) trans;
    forever begin 
        @(vinf.slv_drv_cb);
        vinf.slv_drv_cb.WREADY <= 1;
        end
    endtask
    
    task rsp_write();
    axi_slv_seq_item #(ADDR_W,DATA_W) trans;
    //    @(vinf.slv_drv_cb);
    forever begin 
        wait(rsp_write_q.size() != 0);
        trans = rsp_write_q.pop_front();
        //@(vinf.slv_drv_cb);// iff vinf.slv_drv_cb.WLAST);
        vinf.slv_drv_cb.BID     <= trans.BID;
        vinf.slv_drv_cb.BRESP   <= trans.BRESP;
        vinf.slv_drv_cb.BVALID  <= 1;
        @(vinf.slv_drv_cb iff vinf.slv_drv_cb.BREADY);
        `uvm_info("S_DRV_B_CH",
                 $sformatf("[%0t] CH=B ID=%0d BRESP=%0d",
                            $time,
                            trans.BID,
                            trans.BRESP),
                 UVM_MEDIUM)
       #1;
      //@(vinf.slv_drv_cb);
            if(rsp_write_q.size() == 0) begin
        vinf.slv_drv_cb.BVALID <= 0;
        vinf.slv_drv_cb.BID <= 0;
    end
    end
    endtask

    task addr_read();
    axi_slv_seq_item #(ADDR_W,DATA_W) trans;
    forever begin
        @(vinf.slv_drv_cb);
        vinf.slv_drv_cb.ARREADY <= 1;
    end
    endtask
    
    task data_read();
    axi_slv_seq_item #(ADDR_W,DATA_W) trans;
    forever begin 
        wait(data_read_q.size() != 0);
        trans = data_read_q.pop_front();
        foreach(trans.RDATA[i]) begin
        vinf.slv_drv_cb.RID     <= trans.RID;
        vinf.slv_drv_cb.RDATA   <= trans.RDATA[i];
        vinf.slv_drv_cb.RRESP   <= trans.RRESP;
        vinf.slv_drv_cb.RVALID <= 1'b1;
     //   vinf.slv_drv_cb.RLAST  <= (i == trans.RDATA.size()-1);
        if(i == trans.RDATA.size()-1)
            begin
                vinf.slv_drv_cb.RLAST   <= 1'b1;
            end
        else 
            begin
                vinf.slv_drv_cb.RLAST   <= 1'b0;
            end
        //vinf.slv_drv_cb.RVALID  <= 1;
        `uvm_info("DRV_R_CH",
                 $sformatf("[%0t] CH=R ID=%0d BEAT=%0d DATA=%0h RLAST=%0d",
                            $time,
                            trans.RID,
                            i,
                            trans.RDATA[i],
                            trans.RLAST),
                 UVM_MEDIUM)
        @(vinf.slv_drv_cb iff (vinf.slv_drv_cb.RREADY));
        end
        if(data_read_q.size == 0)begin
       vinf.slv_drv_cb.RVALID <= 0;
        vinf.slv_drv_cb.RLAST <= 0;
       end
    end
    endtask
    
endclass
`endif

