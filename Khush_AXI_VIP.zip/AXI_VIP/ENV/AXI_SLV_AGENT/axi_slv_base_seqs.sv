//======================================================================
// File Name      : axi_SLV_base_seqs.sv
// Module Name    : axi_SLV_base_seqs
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-30 10:26:19
// Last Modified  : 2026-10-05 12:26:21
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_BASE_SEQS_SV
`define AXI_SLV_BASE_SEQS_SV
`define SLV_ADDR_W 32
`define SLV_DATA_W 32
`define SLV_DEPTH 1<<`SLV_ADDR_W

class axi_slv_base_seqs extends uvm_sequence #(axi_slv_seq_item #(`SLV_ADDR_W,`SLV_DATA_W));

    `uvm_object_utils(axi_slv_base_seqs)

    function new(string name="");
        super.new(name);
    endfunction

    bit [`SLV_DATA_W-1:0] slv_mem [(1<<16)-1:0];
    bit [`SLV_ADDR_W-1:0] current_addr;
    `uvm_declare_p_sequencer(axi_slv_seqr #(`SLV_ADDR_W,`SLV_DATA_W))

    function bit [`SLV_ADDR_W-1:0] next_addr_calc(
        bit [`SLV_ADDR_W-1:0] current_addr,
        bit [`SLV_ADDR_W-1:0] start_addr,
        bit [7:0]              burst_len,
        bit [2:0]              burst_size,
        axi_slv_seq_item #(`SLV_ADDR_W,`SLV_DATA_W)::BURST_TYPE burst_type
    );

        bit [`SLV_ADDR_W-1:0] next_addr;
        bit [11:0] total_byte_trasfer = (1<<burst_size)*(burst_len+1);
        bit [`SLV_ADDR_W-1:0] lower_wrap_boundry = (start_addr) - (start_addr % total_byte_trasfer);
        bit [`SLV_ADDR_W-1:0] upper_wrap_boundry = lower_wrap_boundry + total_byte_trasfer;

        case(burst_type)
            axi_slv_seq_item #(`SLV_ADDR_W,`SLV_DATA_W)::FIXED:begin
                                                               next_addr = current_addr;
                                                               end
            axi_slv_seq_item #(`SLV_ADDR_W,`SLV_DATA_W)::INCR :begin
                                                               next_addr = current_addr + (1<<burst_size);
                                                               end
            axi_slv_seq_item #(`SLV_ADDR_W,`SLV_DATA_W)::WRAP :begin
                                                               next_addr = current_addr + (1<<burst_size);
                                                                    if(next_addr >= upper_wrap_boundry)
                                                                        begin
                                                                            next_addr = lower_wrap_boundry;
                                                                        end
                                                               end
        endcase
        return next_addr;
    endfunction

    task slv_mem_imp(axi_slv_seq_item #(`SLV_ADDR_W, `SLV_DATA_W) trans);

        bit [`SLV_ADDR_W-1:0] beat_addr = trans.AWADDR;
        bit [`SLV_ADDR_W-1:0] byte_addr;
        bit [`SLV_ADDR_W-1:0] mem_word_addr;

        int byte_offset;
        int word_bytes = `SLV_DATA_W/8;

        foreach(trans.WDATA[beat])begin

            for(int byte_lane = 0; byte_lane < word_bytes; byte_lane++)begin
                if(trans.WSTRB[beat][byte_lane])begin

                    byte_addr     = beat_addr + byte_lane;
                    byte_offset   = byte_addr % word_bytes;
                    mem_word_addr = byte_addr - byte_offset;

                    slv_mem[mem_word_addr][byte_offset*8 +: 8] = trans.WDATA[beat][byte_lane*8 +: 8];

                    `uvm_info("SLV_MEM_WRITE_BYTE",
                        $sformatf(
                        "[%0t] BEAT=%0d BYTE=%0d BYTE_ADDR=%0h MEM_WORD=%0h OFFSET=%0d DATA=%0h",
                        $time,
                        beat,
                        byte_lane,
                        byte_addr,
                        mem_word_addr,
                        byte_offset,
                        trans.WDATA[beat][byte_lane*8 +: 8]
                        ),
                        UVM_HIGH)
                end
            end

            `uvm_info("SLV_MEM_WRITE",
                $sformatf(
                "[%0d] AXI_ADDR=%04h WDATA=%08h WSTRB=%04b BEAT=%0d",
                $time,
                beat_addr,
                trans.WDATA[beat],
                trans.WSTRB[beat],
                beat),
                UVM_MEDIUM)

            beat_addr = next_addr_calc(beat_addr,trans.AWADDR,trans.AWLEN,trans.AWSIZE,trans.AWBURST);
        end
    endtask

    task slv_mem_read_imp(axi_slv_seq_item #(`SLV_ADDR_W,`SLV_DATA_W) trans);

    bit [`SLV_ADDR_W-1:0] read_addr;
    //Clear the mem after each read operation
    trans.RDATA = new[trans.ARLEN + 1];
  //  foreach (trans.RDATA[i])begin
   //     trans.RDATA[i] = 'h0;
//end
    read_addr = trans.ARADDR;

    foreach(trans.RDATA[beat]) begin
            trans.RDATA[beat] = slv_mem[read_addr];

        `uvm_info("SLV_MEM_READ",
            $sformatf(
            "[%0t] ADDR=%-4h RDATA=%-8h NEW=%-8h BEAT=%0d",
            $time,
            read_addr,
            trans.RDATA[beat],
            slv_mem[read_addr],
            beat),
            UVM_MEDIUM)

        read_addr = next_addr_calc(read_addr,trans.ARADDR,trans.ARLEN,trans.ARSIZE,trans.ARBURST);
    end

endtask

    task body();
    forever begin
	    p_sequencer.req_item_fifo.get(req);
        `uvm_info("SLV_BSEQ",$sformatf("After Fifo_get method TRANS_TYPE:%p",req.transfer_type),UVM_LOW)

    case(req.transfer_type)
      axi_slv_seq_item#(`SLV_ADDR_W,`SLV_DATA_W)::WRITE:

            begin
                `uvm_info("SLV_SEQ_RCV_WRITE",
                    $sformatf("[%0t] Received transaction ID=%0h ADDR=%0h WDATA0=%0h",
                    $time,
                    req.AWID,
                    req.AWADDR,
                    req.WDATA[0]),
                UVM_LOW)
                slv_mem_imp(req);

                rsp = axi_slv_seq_item#(`SLV_ADDR_W,`SLV_DATA_W)::type_id::create("rsp");
                rsp.BID = req.AWID;
                rsp.BRESP = 2'b00;
                start_item(rsp);
                finish_item(rsp);
            end

      axi_slv_seq_item#(`SLV_ADDR_W,`SLV_DATA_W)::READ:

            begin
                `uvm_info("SLV_SEQ_RCV_READ",
                    $sformatf("Received READ ID=%0h ADDR=%0h",
                    req.ARID,
                    req.ARADDR),
                UVM_MEDIUM)
                slv_mem_read_imp(req);

                rsp = axi_slv_seq_item#(`SLV_ADDR_W,`SLV_DATA_W)::type_id::create("rsp");
                rsp.RID = req.ARID;
                rsp.RRESP = 2'b00;
                rsp.RDATA = req.RDATA;
                rsp.transfer_type = axi_slv_seq_item#(`SLV_ADDR_W,`SLV_DATA_W)::READ;

                start_item(rsp);
                finish_item(rsp);
           end
    endcase

    end


endtask

endclass
`endif
