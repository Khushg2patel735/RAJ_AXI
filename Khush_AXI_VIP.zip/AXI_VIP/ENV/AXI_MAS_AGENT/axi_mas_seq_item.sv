//======================================================================
// File Name      : axi_mas_seq_item.sv
// Module Name    : axi_mas_seq_item
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-09-16 12:35:24
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_SEQ_ITEM_SV
`define AXI_MAS_SEQ_ITEM_SV

class axi_mas_seq_item #(int ADDR_W = 32,
                         int DATA_W = 32) extends uvm_sequence_item;
    typedef enum {FIXED,
                  INCR,
                  WRAP} BURST_TYPE_E;
    
    typedef enum {WRITE,
                  READ,
                  SWR} TRANSFER_TYPE_E;
    
        rand    bit AXI3_ACTIVE = 1'b0;
        rand TRANSFER_TYPE_E transfer_type;
        rand   bit [3:0]          AWID;
        rand    bit [ADDR_W-1:0]   AWADDR;
        rand    bit [7:0]          AWLEN;
        rand    bit [2:0]          AWSIZE;
        rand        BURST_TYPE_E     AWBURST;

        rand   bit [3:0]          WID;
        rand    bit [DATA_W-1:0]   WDATA[];
        rand    bit [DATA_W/8-1:0] WSTRB[];
                bit                WLAST;

                bit [3:0]          BID;
                bit [1:0]          BRESP;

        rand    bit [3:0]          ARID;
        rand    bit [ADDR_W-1:0]   ARADDR;
        rand    bit [7:0]          ARLEN;
        rand    bit [2:0]          ARSIZE;
        rand        BURST_TYPE_E     ARBURST;

        rand    bit [3:0]          RID;
                bit [DATA_W-1:0]   RDATA[];
                bit [1:0]          RRESP;
                bit                RLAST;

    
    
//    constraint AWLEN_RENGE {AWLEN inside {1,3,7,15};}
    constraint AWSIZE_RESTRICT {1<<AWSIZE <= DATA_W/8;}


    constraint  DATA_SIZE_C {soft WDATA.size == AWLEN + 1;}
    constraint  STRB_SIZE_C {soft WSTRB.size == AWLEN + 1;}
    
    constraint ID_NOT_0 {AWID != 1'b0; ARID != 1'b0;}
    constraint  AXI_VERSION {  solve AWID before WID;
                                    if(AXI3_ACTIVE)
                                        {
                                            WID == AWID;
                                            AWLEN inside {[0:15]};
                                            ARLEN inside {[0:15]};
                                        }
                                    else
                                        {    WID == 1'b0;
                                             AWLEN inside {[0:255]};
                                            ARLEN inside {[0:255]};
                                        }
                           }
    constraint BOUNDRY_4KB { (AWADDR%4096)+((1<<AWSIZE)*(AWLEN+1)) <= 4096;}

 //constraint id_c {WID == AWID ; /*BID == AWID;*/}

    `uvm_object_param_utils_begin(axi_mas_seq_item#(ADDR_W,DATA_W))
    `uvm_field_int(AWID    , UVM_ALL_ON)
    `uvm_field_int(AWADDR  , UVM_ALL_ON)
    `uvm_field_int(AWLEN   , UVM_ALL_ON)
    `uvm_field_int(AWSIZE  , UVM_ALL_ON)
    `uvm_field_enum(BURST_TYPE_E, AWBURST, UVM_ALL_ON)

    `uvm_field_int(WID     , UVM_ALL_ON)
    `uvm_field_array_int(WDATA   , UVM_ALL_ON)
    `uvm_field_array_int(WSTRB   , UVM_ALL_ON)
    `uvm_field_int(WLAST   , UVM_ALL_ON)

    `uvm_field_int(BID     , UVM_ALL_ON)
    `uvm_field_int(BRESP   , UVM_ALL_ON)

    `uvm_field_int(ARID    , UVM_ALL_ON)
    `uvm_field_int(ARADDR  , UVM_ALL_ON)
    `uvm_field_int(ARLEN   , UVM_ALL_ON)
    `uvm_field_int(ARSIZE  , UVM_ALL_ON)
    `uvm_field_enum(BURST_TYPE_E, ARBURST, UVM_ALL_ON)

    `uvm_field_int(RID     , UVM_ALL_ON)
    `uvm_field_array_int(RDATA   , UVM_ALL_ON)
    `uvm_field_int(RRESP   , UVM_ALL_ON)
    `uvm_field_int(RLAST   , UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name="");
        super.new(name);
    endfunction
endclass
`endif
