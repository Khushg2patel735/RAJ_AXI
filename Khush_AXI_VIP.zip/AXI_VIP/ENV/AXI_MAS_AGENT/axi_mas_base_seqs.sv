//======================================================================
// File Name      : axi_mas_base_seqs.sv
// Module Name    : axi_mas_base_seqs
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-30 10:26:19
// Last Modified  : 2026-09-29 15:46:29
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_BASE_SEQS_SV
`define AXI_MAS_BASE_SEQS_SV
class axi_mas_base_seqs extends uvm_sequence #(axi_mas_seq_item #(`MAS_ADDR_W,`MAS_DATA_W));
   
    `uvm_object_param_utils(axi_mas_base_seqs)

    function new(string name="");
        super.new(name);
    endfunction
    
    int rsp_cnt;

    axi_mas_seq_item #(`MAS_ADDR_W,`MAS_DATA_W) rsp;

    bit [`MAS_ADDR_W-1:0] addr_q[$];

    task pre_start(); 
        use_response_handler(1);
    endtask

   task wait_for_trans_done(int itr_cnt);
    int target_cnt;

    target_cnt = rsp_cnt + itr_cnt;
    wait(rsp_cnt == target_cnt);
    endtask 

    function void response_handler(uvm_sequence_item response);
    rsp_cnt++;
    endfunction




endclass
`endif
