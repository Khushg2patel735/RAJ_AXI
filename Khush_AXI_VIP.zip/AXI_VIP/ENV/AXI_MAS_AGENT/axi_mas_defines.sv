//======================================================================
// File Name      : axi_mas_defines.sv
// Module Name    : axi_mas_defines
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-23 09:56:51
// Last Modified  : 2026-08-02 19:59:06
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_DEFINES_SV
`define AXI_MAS_DEFINES_SV

`define MAS_DATA_W 32
`define MAS_ADDR_W 32
`define MAS_STRB_W `MAS_DATA_W/8

`endif


