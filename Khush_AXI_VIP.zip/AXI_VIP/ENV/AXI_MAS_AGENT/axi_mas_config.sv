//======================================================================
// File Name      : axi_mas_config.sv
// Module Name    : axi_mas_config
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-08-01 23:53:48
// Last Modified  : 2026-10-06 11:37:06
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_CONFIG_SV
`define AXI_MAS_CONFIG_SV
class axi_mas_config extends uvm_object;

    function new(string name="");
        super.new(name);
    endfunction

    uvm_active_passive_enum pipe_drv_enb;
    uvm_active_passive_enum axi3_active;
    bit valid_toggle;

    `uvm_object_utils_begin(axi_mas_config) 
            `uvm_field_enum(uvm_active_passive_enum,pipe_drv_enb,UVM_ALL_ON)
            `uvm_field_enum(uvm_active_passive_enum,axi3_active,UVM_ALL_ON)
            `uvm_field_int(valid_toggle,UVM_ALL_ON)
    `uvm_object_utils_end
endclass

`endif

