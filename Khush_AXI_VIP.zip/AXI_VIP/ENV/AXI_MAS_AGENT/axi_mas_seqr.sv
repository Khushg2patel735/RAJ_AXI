//======================================================================
// File Name      : axi_mas_seqr.sv
// Module Name    : axi_mas_seqr
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-08-26 10:49:14
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_SEQR_SV
`define AXI_MAS_SEQR_SV

class axi_mas_seqr #(int ADDR_W = 32,
                     int DATA_W = 32) extends uvm_sequencer #(axi_mas_seq_item #(ADDR_W,DATA_W));

    `uvm_component_param_utils(axi_mas_seqr #(ADDR_W,DATA_W))

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

endclass
`endif

