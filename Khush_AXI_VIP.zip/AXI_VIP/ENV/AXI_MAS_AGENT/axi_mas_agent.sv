//======================================================================
// File Name      : axi_mas_agent.sv
// Module Name    : axi_mas_agent
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-08-07 15:12:52
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_MAS_AGENT_SV
`define AXI_MAS_AGENT_SV

class axi_mas_agent #(int ADDR_W = 32,
                      int DATA_W = 32) extends uvm_agent;

    `uvm_component_param_utils(axi_mas_agent #(ADDR_W,DATA_W))

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

    axi_mas_seqr    #(ADDR_W, DATA_W) seqr_h;
    axi_mas_drv     #(ADDR_W, DATA_W) drv_h;
    axi_mas_mon     #(ADDR_W, DATA_W) mon_h;
    virtual axi_mas_inf #(ADDR_W, DATA_W) vinf;

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        seqr_h = axi_mas_seqr #(ADDR_W, DATA_W)::type_id::create("seqr_h",this);
        drv_h  = axi_mas_drv  #(ADDR_W, DATA_W)::type_id::create("drv_h",this);
        mon_h  = axi_mas_mon  #(ADDR_W, DATA_W)::type_id::create("mon_h",this);

        if(!uvm_config_db #(virtual axi_mas_inf #(ADDR_W, DATA_W))::get(this,"","vinf",vinf))
            `uvm_fatal("MAS_AGENT","Virtual Interface Get method doesn't impliment")
    endfunction

    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        drv_h.seq_item_port.connect(seqr_h.seq_item_export);
        drv_h.vinf = vinf;
    endfunction

endclass
`endif

