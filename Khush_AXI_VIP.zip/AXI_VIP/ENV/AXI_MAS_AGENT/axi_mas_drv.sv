//======================================================================
// File Name      : axi_mas_drv.sv
// Module Name    : axi_mas_drv
// Project        : AXI_VIP
// Author         : Khush Patel
// Language       : SystemVerilog
//
// Description    : AXI Master Driver
//
// Functionality  :
//   - Separate queue for each AXI channel
//   - Supports pipelined channel operation
//   - Handles B/R responses
//   - Generates sequence responses using put_response()
//   - Uses ev for non-pipelined transaction completion
//
//======================================================================

`ifndef AXI_MAS_DRV_SV
`define AXI_MAS_DRV_SV


class axi_mas_drv #(int ADDR_W = 32,
                    int DATA_W = 32)
    extends uvm_driver #(
        axi_mas_seq_item #(ADDR_W,DATA_W),
        axi_mas_seq_item #(ADDR_W,DATA_W)
    );

    `uvm_component_param_utils(axi_mas_drv #(ADDR_W,DATA_W))


    //==============================================================
    // Virtual Interface
    //==============================================================

    virtual axi_mas_inf #(ADDR_W,DATA_W).MAS_DRV_MP vinf;


    //==============================================================
    // Event
    // Used for non-pipelined driver completion
    //==============================================================

    event ev;


    //==============================================================
    // Channel Queues
    //==============================================================

    axi_mas_seq_item #(ADDR_W,DATA_W) addr_write_q [$];
    axi_mas_seq_item #(ADDR_W,DATA_W) data_write_q [$];
    axi_mas_seq_item #(ADDR_W,DATA_W) rsp_write_q  [$];

    axi_mas_seq_item #(ADDR_W,DATA_W) addr_read_q  [$];
    axi_mas_seq_item #(ADDR_W,DATA_W) data_read_q  [$];


    //==============================================================
    // Configuration
    //==============================================================

    axi_mas_config mas_cfg_h;


    //==============================================================
    // Constructor
    //==============================================================

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction


    //==============================================================
    // BUILD PHASE
    //==============================================================

    function void build_phase(uvm_phase phase);

        super.build_phase(phase);

        mas_cfg_h =
            axi_mas_config::type_id::create("mas_cfg_h");

        if(!uvm_config_db #(axi_mas_config)::get(
                this,
                "",
                "mas_cfg_h",
                mas_cfg_h))
        begin
            `uvm_error(
                "MAS_CFG",
                "MAS config fail to get"
            )
        end

    endfunction


    //==============================================================
    // RUN PHASE
    //==============================================================

    task run_phase(uvm_phase phase);

        axi_mas_seq_item #(ADDR_W,DATA_W) req;


        //==========================================================
        // Collect sequence items and distribute them into
        // individual channel queues.
        //==========================================================

        fork

            forever begin

                seq_item_port.get_next_item(req);


                case(req.transfer_type)


                    //================================================
                    // WRITE
                    //================================================

                    axi_mas_seq_item#(ADDR_W,DATA_W)::WRITE:
                    begin

                        addr_write_q.push_back(req);

                        data_write_q.push_back(req);

                        // Keep original transaction until B response
                        rsp_write_q.push_back(req);

                    end


                    //================================================
                    // READ
                    //================================================

                    axi_mas_seq_item#(ADDR_W,DATA_W)::READ:
                    begin

                        addr_read_q.push_back(req);

                        // Keep original transaction until RLAST
                        data_read_q.push_back(req);

                    end


                    //================================================
                    // WRITE + READ
                    //================================================

                    axi_mas_seq_item#(ADDR_W,DATA_W)::SWR:
                    begin

                        addr_write_q.push_back(req);

                        data_write_q.push_back(req);

                        rsp_write_q.push_back(req);

                        addr_read_q.push_back(req);

                        data_read_q.push_back(req);

                    end

                endcase


                //====================================================
                // Non-pipelined mode
                // Wait until actual protocol response is complete.
                //====================================================

                if (!mas_cfg_h.pipe_drv_enb)
                    @(ev);


                seq_item_port.item_done();

            end

        join_none


        //==========================================================
        // Driver mode information
        //==========================================================

        if (mas_cfg_h.pipe_drv_enb)

            `uvm_info(
                "PIPE_DRV_ON",
                $sformatf(
                    "pipe_drv_enb = %0d",
                    mas_cfg_h.pipe_drv_enb
                ),
                UVM_MEDIUM
            )

        else

            `uvm_info(
                "PIPE_DRV_OFF",
                $sformatf(
                    "pipe_drv_enb = %0d",
                    mas_cfg_h.pipe_drv_enb
                ),
                UVM_MEDIUM
            );


        //==========================================================
        // Start individual channel processes
        //==========================================================

        fork

            addr_write();

            data_write();

            rsp_write();

            addr_read();

            data_read();

        join_none

    endtask



    //################################################################
    // WRITE ADDRESS CHANNEL
    //################################################################

    task addr_write();

        axi_mas_seq_item #(ADDR_W,DATA_W) trans;


        forever begin

            wait(addr_write_q.size() != 0);

            trans = addr_write_q.pop_front();


            //========================================================
            // Drive AW channel
            //========================================================

            vinf.mas_drv_cb.AWID     <= trans.AWID;
            vinf.mas_drv_cb.AWADDR   <= trans.AWADDR;
            vinf.mas_drv_cb.AWLEN    <= trans.AWLEN;
            vinf.mas_drv_cb.AWSIZE   <= trans.AWSIZE;
            vinf.mas_drv_cb.AWBURST  <= trans.AWBURST;

            vinf.mas_drv_cb.AWVALID  <= 1'b1;


            //========================================================
            // Wait for AW handshake
            //========================================================

            @(vinf.mas_drv_cb iff
                (vinf.mas_drv_cb.AWREADY));


            `uvm_info(
                "MAS_DRV_AW_CH",
                $sformatf(
                    "[%0t] CH=AW ID=%0h ADDR=%0h LEN=%0d SIZE=%0d",
                    $time,
                    trans.AWID,
                    trans.AWADDR,
                    trans.AWLEN,
                    trans.AWSIZE
                ),
                UVM_MEDIUM
            );


            //========================================================
            // If there is no next AW transaction,
            // deassert AWVALID.
            //========================================================

            if(addr_write_q.size() == 0)

                vinf.mas_drv_cb.AWVALID <= 1'b0;

        end

    endtask



    //################################################################
    // WRITE DATA CHANNEL
    //################################################################

    task data_write();

        axi_mas_seq_item #(ADDR_W,DATA_W) trans;


        forever begin

            wait(data_write_q.size() != 0);

            trans = data_write_q.pop_front();


            //========================================================
            // Send every WDATA beat
            //========================================================

            foreach(trans.WDATA[i]) begin


                vinf.mas_drv_cb.WID   <= trans.WID;

                vinf.mas_drv_cb.WDATA <= trans.WDATA[i];

                vinf.mas_drv_cb.WSTRB <= trans.WSTRB[i];


                //====================================================
                // WLAST
                //====================================================

                if(i == trans.AWLEN)

                    vinf.mas_drv_cb.WLAST <= 1'b1;

                else

                    vinf.mas_drv_cb.WLAST <= 1'b0;


                vinf.mas_drv_cb.WVALID <= 1'b1;


                `uvm_info(
                    "MAS_DRV_W_CH",
                    $sformatf(
                        "[%0t] CH=DW ID=%0h BEAT=%0d DATA=%0h WLAST=%0d",
                        $time,
                        trans.WID,
                        i,
                        trans.WDATA[i],
                        (i == trans.AWLEN)
                    ),
                    UVM_MEDIUM
                );


                //====================================================
                // Wait for W handshake
                //====================================================

                @(vinf.mas_drv_cb iff
                    (vinf.mas_drv_cb.WREADY));

            end


            //========================================================
            // Current transaction completed.
            // If no next W transaction is waiting,
            // deassert WVALID and WLAST.
            //========================================================

            if(data_write_q.size() == 0) begin

                vinf.mas_drv_cb.WVALID <= 1'b0;

                vinf.mas_drv_cb.WLAST  <= 1'b0;

            end

        end

    endtask



    //################################################################
    // WRITE RESPONSE CHANNEL
    //################################################################

    task rsp_write();

        axi_mas_seq_item #(ADDR_W,DATA_W) trans;

        axi_mas_seq_item #(ADDR_W,DATA_W) rsp;


        forever begin

            //========================================================
            // Wait for a write transaction whose B response
            // is expected.
            //========================================================

            wait(rsp_write_q.size() != 0);

            trans = rsp_write_q.pop_front();


            //========================================================
            // Master is always ready for B response.
            //========================================================

            vinf.mas_drv_cb.BREADY <= 1'b1;


            //========================================================
            // Wait for BVALID.
            //
            // IMPORTANT:
            // BREADY is an output of the clocking block, therefore
            // don't use BREADY inside the iff expression.
            //
            // Since BREADY is already HIGH:
            //
            // BVALID = 1
            //
            // means BVALID && BREADY handshake.
            //========================================================

            @(vinf.mas_drv_cb iff
                (vinf.mas_drv_cb.BVALID));


            `uvm_info(
                "MAS_DRV_B_CH",
                $sformatf(
                    "[%0t] CH=B BID=%0h BRESP=%0h",
                    $time,
                    vinf.mas_drv_cb.BID,
                    vinf.mas_drv_cb.BRESP
                ),
                UVM_MEDIUM
            );


            //========================================================
            // Create response transaction
            //========================================================

            $cast(
                rsp,
                trans.clone()
            );


            rsp.BID   = vinf.mas_drv_cb.BID;

            rsp.BRESP = vinf.mas_drv_cb.BRESP;


            //========================================================
            // Preserve sequence ID information
            //========================================================

            rsp.set_id_info(trans);


            //========================================================
            // Send response back to sequence
            //========================================================

            seq_item_port.put_response(rsp);


            //========================================================
            // Tell non-pipelined driver that transaction completed
            //========================================================

            ->ev;

        end

    endtask



    //################################################################
    // READ ADDRESS CHANNEL
    //################################################################

    task addr_read();

        axi_mas_seq_item #(ADDR_W,DATA_W) trans;


        forever begin

            wait(addr_read_q.size() != 0);

            trans = addr_read_q.pop_front();


            //========================================================
            // Drive AR channel
            //========================================================

            vinf.mas_drv_cb.ARID     <= trans.ARID;

            vinf.mas_drv_cb.ARADDR   <= trans.ARADDR;

            vinf.mas_drv_cb.ARLEN    <= trans.ARLEN;

            vinf.mas_drv_cb.ARSIZE   <= trans.ARSIZE;

            vinf.mas_drv_cb.ARBURST  <= trans.ARBURST;

            vinf.mas_drv_cb.ARVALID  <= 1'b1;


            //========================================================
            // Wait for AR handshake
            //========================================================

            @(vinf.mas_drv_cb iff
                (vinf.mas_drv_cb.ARREADY));


            `uvm_info(
                "MAS_DRV_AR_CH",
                $sformatf(
                    "[%0t] CH=AR ID=%0h ADDR=%0h LEN=%0d SIZE=%0d",
                    $time,
                    trans.ARID,
                    trans.ARADDR,
                    trans.ARLEN,
                    trans.ARSIZE
                ),
                UVM_MEDIUM
            );


            //========================================================
            // IMPORTANT:
            //
            // Check addr_read_q, NOT addr_write_q.
            //========================================================

            if(addr_read_q.size() == 0)

                vinf.mas_drv_cb.ARVALID <= 1'b0;

        end

    endtask



    //################################################################
    // READ DATA CHANNEL
    //################################################################

    task data_read();

        axi_mas_seq_item #(ADDR_W,DATA_W) trans;

        axi_mas_seq_item #(ADDR_W,DATA_W) rsp;


        int beat;


        forever begin

            wait(data_read_q.size() != 0);

            trans = data_read_q.pop_front();


            //========================================================
            // Allocate space for returned RDATA
            //========================================================

            $cast(
                rsp,
                trans.clone()
            );


            rsp.RDATA = new[trans.ARLEN + 1];


            beat = 0;


            //========================================================
            // Master is ready for R channel
            //========================================================

            vinf.mas_drv_cb.RREADY <= 1'b1;


            //========================================================
            // Receive R beats
            //========================================================

            forever begin


                //====================================================
                // Wait for RVALID.
                //
                // RREADY is already HIGH, therefore:
                //
                // RVALID = 1
                //
                // means RVALID && RREADY handshake.
                //====================================================

                @(vinf.mas_drv_cb iff
                    (vinf.mas_drv_cb.RVALID));


                //====================================================
                // Capture R channel
                //====================================================

                rsp.RID   = vinf.mas_drv_cb.RID;

                rsp.RRESP = vinf.mas_drv_cb.RRESP;

                rsp.RDATA[beat] = vinf.mas_drv_cb.RDATA;


                `uvm_info(
                    "MAS_DRV_R_CH",
                    $sformatf(
                        "[%0t] CH=R ID=%0h BEAT=%0d DATA=%0h RLAST=%0d RRESP=%0h",
                        $time,
                        vinf.mas_drv_cb.RID,
                        beat,
                        vinf.mas_drv_cb.RDATA,
                        vinf.mas_drv_cb.RLAST,
                        vinf.mas_drv_cb.RRESP
                    ),
                    UVM_MEDIUM
                );


                //====================================================
                // Last R beat
                //====================================================

                if(vinf.mas_drv_cb.RLAST) begin


                    //================================================
                    // Preserve sequence ID information
                    //================================================

                    rsp.set_id_info(trans);


                    //================================================
                    // Return completed read transaction
                    //================================================

                    seq_item_port.put_response(rsp);


                    //================================================
                    // Signal transaction completion
                    //================================================

                    ->ev;


                    break;

                end


                //====================================================
                // Move to next R beat
                //====================================================

                beat++;

            end

        end

    endtask


endclass

`endif

