//======================================================================
// File Name      : axi_slv_drv.sv
// Module Name    : axi_slv_drv
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-07-23 22:30:31
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_DRV_SV
`define AXI_SLV_DRV_SV

class axi_slv_drv #(int ADDR_W = 32,
                    int DATA_W = 32) extends uvm_driver #(axi_slv_seq_item #(ADDR_W,DATA_W));

    `uvm_component_param_utils(axi_slv_drv #(ADDR_W,DATA_W)) 

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

endclass
`endif
