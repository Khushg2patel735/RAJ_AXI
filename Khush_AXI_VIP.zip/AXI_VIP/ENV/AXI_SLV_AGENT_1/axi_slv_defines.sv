//======================================================================
// File Name      : axi_slv_defines.sv
// Module Name    : axi_slv_defines
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-23 09:56:51
// Last Modified  : 2026-07-23 22:28:54
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_DEFINES_SV
`define AXI_SLV_DEFINES_SV

`define DATA_W 32
`define ADDR_W 32
`define STRB_W `DATA_W/8

`endif


