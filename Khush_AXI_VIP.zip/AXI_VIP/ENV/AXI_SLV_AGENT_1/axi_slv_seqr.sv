//======================================================================
// File Name      : axi_slv_seqr.sv
// Module Name    : axi_slv_seqr
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-07-23 22:30:39
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_SEQR_SV
`define AXI_SLV_SEQR_SV

class axi_slv_seqr #(int ADDR_W = 32,
                     int DATA_W = 32) extends uvm_sequencer #(axi_slv_seq_item #(ADDR_W,DATA_W));

    `uvm_component_param_utils(axi_slv_seqr #(ADDR_W,DATA_W))

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

endclass
`endif

