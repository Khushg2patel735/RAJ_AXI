//======================================================================
// File Name      : axi_slv_mon.sv
// Module Name    : axi_slv_mon
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-07-25 19:35:59
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_MON_SV
`define AXI_SLV_MON_SV

class axi_slv_mon #(int ADDR_W = 32,
                    int DATA_W = 32) extends uvm_monitor;

    `uvm_component_param_utils(axi_slv_mon #(ADDR_W,DATA_W))

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

endclass
`endif

