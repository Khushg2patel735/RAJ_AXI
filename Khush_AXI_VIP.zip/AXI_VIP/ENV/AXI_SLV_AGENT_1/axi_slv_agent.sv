//======================================================================
// File Name      : axi_slv_agent.sv
// Module Name    : axi_slv_agent
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-07-23 22:38:13
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_AGENT_SV
`define AXI_SLV_AGENT_SV

class axi_slv_agent #(int ADDR_W = 32,
                      int DATA_W = 32) extends uvm_agent;

    `uvm_component_param_utils(axi_slv_agent #(ADDR_W,DATA_W))

    function new(string name="", uvm_component parent);
        super.new(name,parent);
    endfunction

    axi_slv_seqr #(ADDR_W, DATA_W) seqr_h;
    axi_slv_drv  #(ADDR_W, DATA_W) drv_h;
    axi_slv_mon  #(ADDR_W, DATA_W) mon_h;

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        seqr_h = axi_slv_seqr#(ADDR_W, DATA_W)::type_id::create("seqr_h",this);
        drv_h  = axi_slv_drv#(ADDR_W, DATA_W)::type_id::create("drv_h",this);
        mon_h  = axi_slv_mon#(ADDR_W, DATA_W)::type_id::create("mon_h",this);
    endfunction

    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        drv_h.seq_item_port.connect(seqr_h.seq_item_export);
    endfunction

endclass
`endif

