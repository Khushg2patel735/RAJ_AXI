//======================================================================
// File Name      : axi_slv_seq_item.sv
// Module Name    : axi_slv_seq_item
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-20 20:37:18
// Last Modified  : 2026-07-23 22:29:27
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SLV_SEQ_ITEM_SV
`define AXI_SLV_SEQ_ITEM_SV

class axi_slv_seq_item #(int ADDR_W = 32,
                         int DATA_W = 32) extends uvm_sequence_item;

    `uvm_object_param_utils_begin(axi_slv_seq_item#(ADDR_W,DATA_W))
    `uvm_object_utils_end

    function new(string name="");
        super.new(name);
    endfunction
endclass
`endif
