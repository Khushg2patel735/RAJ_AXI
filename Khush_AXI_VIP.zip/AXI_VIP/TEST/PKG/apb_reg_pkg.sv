//------------------------------------------------------------
// File Name   : axi_slv_pkg.sv
// Module Name : axi_slv_pkg
// Project     : Dual_PORT_RAM_Layered_TB
// Author      : Khush Patel

// Created On  : 2026-06-24 18:42:22
// Last Mod    : 2026-06-25 12:52:27
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_REG_PKG
`define AXI_REG_PKG
`include "uvm_macros.svh"
package axi_reg_pkg;
import uvm_pkg::*;

`include "axi_mas_defines.sv"
`include "axi_reg_seq_item.sv"
`include "axi_reg_seqr.sv"
`include "axi_reg_drv.sv"
`include "axi_reg_mon.sv"
`include "axi_reg_agent.sv"
`include "axi_reg_base_seqs.sv"
endpackage
`endif
