//------------------------------------------------------------
// File Name   : axi_mas_pkg.sv
// Module Name : axi_mas_pkg
// Project        : AXI_VIP
// Author      : Khush Patel

// Created On  : 2026-06-24 18:42:22
// Last Mod    : 2026-06-25 12:51:57
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_MAS_PKG
`define AXI_MAS_PKG

`include "uvm_macros.svh"
`include "axi_mas_inf.sv"
package axi_mas_pkg;
import uvm_pkg::*;

`include "axi_mas_config.sv"
`include "axi_mas_defines.sv"
`include "axi_mas_seq_item.sv"
`include "axi_mas_seqr.sv"
`include "axi_mas_drv.sv"
`include "axi_mas_mon.sv"
`include "axi_mas_agent.sv"
`include "axi_mas_base_seqs.sv"
endpackage
`endif
