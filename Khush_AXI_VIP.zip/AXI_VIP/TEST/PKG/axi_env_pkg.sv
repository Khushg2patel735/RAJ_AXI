//------------------------------------------------------------
// File Name   : axi_env_pkg.sv
// Module Name : axi_env_pkg
// Project        : AXI_VIP
// Author      : Khush Patel

// Created On  : 2026-06-24 18:42:22
// Last Mod    : 2026-07-20 17:07:40
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_ENV_PKG
`define AXI_ENV_PKG
`include "uvm_macros.svh"
//`include "axi_inf.sv"
`include "axi_mas_pkg.sv"
`include "axi_slv_pkg.sv"

package axi_env_pkg;
import uvm_pkg::*;

import axi_mas_pkg::*;
import axi_slv_pkg::*;

`include "axi_env_config.sv"
`include "axi_vsqer.sv"
`include "axi_base_vseqs.sv"
//`include "axi_mas_sb.sv"
`include "axi_env.sv"


endpackage
`endif
