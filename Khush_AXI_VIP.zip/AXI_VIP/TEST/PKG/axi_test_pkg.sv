//------------------------------------------------------------
// File Name   : axi_pkg.sv
// Module Name : axi_pkg
// Project        : AXI_VIP
// Author      : Khush Patel

// Created On  : 2026-06-24 18:41:30
// Last Mod    : 2026-07-16 12:25:47
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_TEST_PKG
`define AXI_TEST_PKG
`include "uvm_macros.svh"
`include "axi_mas_pkg.sv"
`include "axi_slv_pkg.sv"
`include "axi_env_pkg.sv"

//---------- TEST PACKAGE ----------
package axi_test_pkg;
import uvm_pkg::*;
import axi_mas_pkg::*;
import axi_slv_pkg::*;
import axi_env_pkg::*;

//event axi_reset;
//event reg_reset;
`include "axi_sanity_seqs.sv"
`include "axi_sanity_vseqs.sv"
`include "axi_base_test.sv"
`include "axi_sanity_test.sv"

endpackage
`endif


