//------------------------------------------------------------
// File Name   : axi_slv_pkg.sv
// Module Name : axi_slv_pkg
// Project        : AXI_VIP
// Author      : Khush Patel

// Created On  : 2026-06-24 18:42:22
// Last Mod    : 2026-06-25 12:51:57
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_SLV_PKG
`define AXI_SLV_PKG

`include "uvm_macros.svh"
`include "axi_slv_inf.sv"

package axi_slv_pkg;
import uvm_pkg::*;

`include "axi_slv_defines.sv"
`include "axi_slv_seq_item.sv"
`include "axi_slv_seqr.sv"
`include "axi_slv_drv.sv"
`include "axi_slv_mon.sv"
`include "axi_slv_agent.sv"
`include "axi_slv_base_seqs.sv"
endpackage
`endif
