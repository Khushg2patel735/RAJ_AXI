
//------------------------------------------------------------
// File Name   : axi_base_test.sv
// Module Name : axi_base_test
// Project        : AXI_VIP
// Author      : Khush Patel

// Created On  : 2026-06-23 15:11:02
// Last Mod    : 2026-06-25 12:51:49
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_BASE_TEST_SV
`define AXI_BASE_TEST_SV

class axi_base_test extends uvm_test;

    `uvm_component_utils(axi_base_test)
    axi_env env_h;
    axi_env_config env_cfg_h;
    
    //want pipline based driver enable then 1 else 0
    //virtual axi_inf vinf;
  function new(string name="", uvm_component parent);
    super.new(name,parent);
  endfunction
  
    function void config_set();
        env_cfg_h.pipe_drv_enb = UVM_ACTIVE;
        env_cfg_h.axi3_active =  UVM_PASSIVE;
        env_cfg_h.valid_toggle = 1'b0;
    endfunction

  function void build_phase(uvm_phase phase);
  super.build_phase(phase);
    env_cfg_h = axi_env_config::type_id::create("env_cfg_h");
        config_set();
    uvm_config_db #(axi_env_config)::set(this,"env_h*","env_cfg_h",env_cfg_h);
   env_h = axi_env::type_id::create("env_h",this);
    
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    uvm_top.print_topology();
  endfunction

endclass
`endif

