//------------------------------------------------------------
// File Name   : apb_mas_pkg.sv
// Module Name : apb_mas_pkg
// Project     : Dual_PORT_RAM_Layered_TB
// Author      : Khush Patel

// Created On  : 2026-06-24 18:42:22
// Last Mod    : 2026-06-25 12:51:57
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef APB_MAS_PKG
`define APB_MAS_PKG

`include "uvm_macros.svh"

package apb_mas_pkg;
import uvm_pkg::*;

`include "apb_mas_defines.sv"
`include "apb_mas_seq_item.sv"
`include "apb_mas_seqr.sv"
`include "apb_mas_drv.sv"
`include "apb_mas_mon.sv"
`include "apb_mas_agent.sv"
`include "apb_mas_base_seqs.sv"
endpackage
`endif
