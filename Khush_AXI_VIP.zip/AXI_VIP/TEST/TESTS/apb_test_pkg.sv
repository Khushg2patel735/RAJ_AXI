//------------------------------------------------------------
// File Name   : apb_pkg.sv
// Module Name : apb_pkg
// Project     : Dual_PORT_RAM_Layered_TB
// Author      : Khush Patel

// Created On  : 2026-06-24 18:41:30
// Last Mod    : 2026-07-16 12:25:47
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef APB_PKG
`define APB_PKG
`include "uvm_macros.svh"
`include "apb_mas_pkg.sv"
`include "apb_reg_pkg.sv"
`include "apb_env_pkg.sv"

//---------- TEST PACKAGE ----------
package apb_test_pkg;
import uvm_pkg::*;
import apb_mas_pkg::*;
import apb_reg_pkg::*;
import apb_env_pkg::*;

event apb_reset;
event reg_reset;

`include "apb_mas_b2b_wr_seqs.svh"
`include "apb_reg_mem_enb_seqs.svh"
`include "apb_reg_mem_disenb_seqs.svh"
`include "apb_reg_slv_sel_seqs.svh"
`include "apb_mas_reset_seqs.svh"
`include "apb_b2b_wr_vseqs.sv"
`include "apb_reset_vseqs.sv"
`include "apb_base_test.sv"
`include "apb_mas_b2b_wr_test.svh"
`include "apb_mas_reset_test.svh"

endpackage
`endif


