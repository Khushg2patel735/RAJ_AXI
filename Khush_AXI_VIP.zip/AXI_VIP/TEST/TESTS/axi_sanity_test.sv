
//------------------------------------------------------------
// File Name   : axi_sanity_test.sv
// Module Name : axi_sanity_test
// Project        : AXI_VIP
// Author      : Khush Patel

// Created On  : 2026-06-23 15:11:02
// Last Mod    : 2026-06-25 12:51:49
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef AXI_SANITY_TEST_SV
`define AXI_SANITY_TEST_SV

class axi_sanity_test extends axi_base_test;

    `uvm_component_utils(axi_sanity_test)
    axi_sanity_vseqs vseqs_h;
    //want pipline based driver enable then 1 else 0
    //virtual axi_inf vinf;
  function new(string name="", uvm_component parent);
    super.new(name,parent);
  endfunction
  
  function void build_phase(uvm_phase phase);
  super.build_phase(phase);
    vseqs_h = axi_sanity_vseqs::type_id::create("vseqs_h");
    
  endfunction

   task run_phase(uvm_phase phase);
     phase.raise_objection(this);
        vseqs_h.start(env_h.vseqr_h);
        // seqs2_h.start(env_h.reg_agent_h.seqr_h);
 //    phase.phase_done.set_drain_time(this,430ns);
 // if(is_pipline_enb) phase.phase_done.set_drain_time(this,430ns);
  //  #1000; 
    phase.drop_objection(this);
   endtask
endclass
`endif

