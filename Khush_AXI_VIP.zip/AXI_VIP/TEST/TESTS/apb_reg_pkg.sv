//------------------------------------------------------------
// File Name   : apb_slv_pkg.sv
// Module Name : apb_slv_pkg
// Project     : Dual_PORT_RAM_Layered_TB
// Author      : Khush Patel

// Created On  : 2026-06-24 18:42:22
// Last Mod    : 2026-06-25 12:52:27
// Language    : SystemVerilog
// Description : 
//   
// Functionality:
//   
// Ports:
//   
//   
//
// Notes:
//   
//   
//------------------------------------------------------------
`ifndef APB_REG_PKG
`define APB_REG_PKG
`include "uvm_macros.svh"
package apb_reg_pkg;
import uvm_pkg::*;

`include "apb_mas_defines.sv"
`include "apb_reg_seq_item.sv"
`include "apb_reg_seqr.sv"
`include "apb_reg_drv.sv"
`include "apb_reg_mon.sv"
`include "apb_reg_agent.sv"
`include "apb_reg_base_seqs.sv"
endpackage
`endif
