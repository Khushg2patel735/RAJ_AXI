//======================================================================
// File Name      : axi_sanity_seqs.sv
// Module Name    : axi_sanity_seqs
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-07-30 22:54:42
// Last Modified  : 2026-10-06 19:04:45
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SANITY_SEQS_SV
`define AXI_SANITY_SEQS_SV
class axi_sanity_seqs extends axi_mas_base_seqs;
   
    `uvm_object_utils(axi_sanity_seqs)

    function new(string name="");
        super.new(name);
    endfunction
    
   
    int no_itr = 3;

    task body();

        // WRITE phase
        repeat(no_itr) begin
            write();
        end

        // Wait for B responses
        wait_for_trans_done(no_itr);


        // READ phase
        repeat(no_itr) begin
            read();
        end

        // Wait for final R responses
        wait_for_trans_done(no_itr);

        #20;

    endtask

    task write();

        req = axi_mas_seq_item #(`MAS_ADDR_W,`MAS_DATA_W)::
              type_id::create("req");

        start_item(req);

        if(!req.randomize() with {

            transfer_type == WRITE;

            AXI3_ACTIVE == 1'b1;

            // Select the starting address
            AWADDR inside {
                'h1000,
                'h1004,
                'h1008,
                'h100c,
                'h1010
            };

            // 4 beats
            AWLEN == 2'b11;

            // 4 bytes/beat for 32-bit data
            AWSIZE == 2'h2;

            // Incrementing burst
            AWBURST == INCR;

            AWID inside {[1:15]};

        })
        begin

            `uvm_fatal(
                "SANITY_SEQS_WRITE",
                "Randomize fail at sanity seqs."
            )

        end


        //==============================================================
        // Save the starting address for later READ
        //==============================================================

        addr_q.push_back(req.AWADDR);


        `uvm_info(
            "SANITY_WRITE",
            $sformatf(
                "[%0t] WRITE ADDR=%0h ID=%0h LEN=%0d SIZE=%0d BURST=%0d",
                $time,
                req.AWADDR,
                req.AWID,
                req.AWLEN,
                req.AWSIZE,
                req.AWBURST
            ),
            UVM_MEDIUM
        );


        finish_item(req);

    endtask

    task read();

        bit [`MAS_ADDR_W-1:0] read_addr;

        req = axi_mas_seq_item #(`MAS_ADDR_W,`MAS_DATA_W)::
          type_id::create("req");

        if(addr_q.size() == 0)
            `uvm_fatal("SANITY_SEQS_READ",
                       "No address available for READ")

        read_addr = addr_q.pop_front();

        start_item(req);

        if(!req.randomize() with {
            transfer_type == READ;
            AXI3_ACTIVE  == 1'b1;

            ARADDR  == read_addr;
            ARLEN   == 2'b11;
            ARSIZE  == 2'h2;
            ARBURST == INCR;
            ARID inside {[1:15]};
        })
            `uvm_fatal(
                "SANITY_SEQS_READ",
                "Randomize fail at sanity seqs."
            );

        finish_item(req);

    endtask

endclass
`endif
