//======================================================================
// File Name      : axi_sanity_vseqs.sv
// Module Name    : axi_sanity_vseqs
// Project        : AXI_VIP
// Author         : Khush Patel
// Created On     : 2026-08-02 18:56:59
// Last Modified  : 2026-09-16 14:33:35
// Language       : SystemVerilog
//
// Description    :
//
// Functionality  :
//
// Ports          :
//
// Notes          :
//
//======================================================================
`ifndef AXI_SANITY_VSEQS_SV
`define AXI_SANITY_VSEQS_SV

class axi_sanity_vseqs extends axi_base_vseqs;
  
  `uvm_object_utils(axi_sanity_vseqs)
  
    axi_sanity_seqs seqs1_h;
    axi_slv_base_seqs seqs2_h;

  function new(string name="");
      super.new(name);
  endfunction	 

    task body();
    seqs1_h = axi_sanity_seqs::type_id::create("seqs1_h");
    seqs2_h = axi_slv_base_seqs::type_id::create("seqs2_h");
    fork
    seqs2_h.start(vseqr_h.slv_seqr_h);
    join_none
    seqs1_h.start(vseqr_h.mas_seqr_h);
    endtask
endclass
`endif

