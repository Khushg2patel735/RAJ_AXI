`ifndef AXI_TOP
`define AXI_TOP

`include "uvm_macros.svh"
`include "axi_mas_defines.sv"
`include "axi_mas_inf.sv"
`include "axi_slv_inf.sv"
`include "axi_test_pkg.sv"

//---------- TOP ----------
module axi_tb_top;
import uvm_pkg::*;
import axi_mas_pkg::*;
import axi_slv_pkg::*;
import axi_env_pkg::*;
import axi_test_pkg::*;

    bit ACLK;
        axi_mas_inf #(`MAS_ADDR_W,`MAS_DATA_W) axi_mas_inf(ACLK);
        axi_slv_inf #(`SLV_ADDR_W,`SLV_DATA_W) axi_slv_inf(ACLK);

    initial begin
        ACLK = 0;
        forever #5 ACLK = ~ACLK;
    end

//SLV --> MAS
	assign axi_mas_inf.AWREADY = axi_slv_inf.AWREADY;
	
	assign axi_mas_inf.WREADY  = axi_slv_inf.WREADY;
	
	assign axi_mas_inf.BID     = axi_slv_inf.BID;
	assign axi_mas_inf.BRESP   = axi_slv_inf.BRESP;
	assign axi_mas_inf.BVALID  = axi_slv_inf.BVALID;
	
	assign axi_mas_inf.ARREADY = axi_slv_inf.ARREADY;
	
	assign axi_mas_inf.RID     = axi_slv_inf.RID;
	assign axi_mas_inf.RDATA   = axi_slv_inf.RDATA;
	assign axi_mas_inf.RRESP   = axi_slv_inf.RRESP;
	assign axi_mas_inf.RLAST   = axi_slv_inf.RLAST;
	assign axi_mas_inf.RVALID  = axi_slv_inf.RVALID;

//MAS --> SLV
	assign axi_slv_inf.AWID    = axi_mas_inf.AWID;
    assign axi_slv_inf.AWADDR  = axi_mas_inf.AWADDR;
    assign axi_slv_inf.AWLEN   = axi_mas_inf.AWLEN;
    assign axi_slv_inf.AWSIZE  = axi_mas_inf.AWSIZE;
    assign axi_slv_inf.AWBURST = axi_mas_inf.AWBURST;
    assign axi_slv_inf.AWVALID = axi_mas_inf.AWVALID;
	
    assign axi_slv_inf.WID     = axi_mas_inf.WID;
    assign axi_slv_inf.WDATA   = axi_mas_inf.WDATA;
    assign axi_slv_inf.WSTRB   = axi_mas_inf.WSTRB;
    assign axi_slv_inf.WLAST   = axi_mas_inf.WLAST;
    assign axi_slv_inf.WVALID  = axi_mas_inf.WVALID;
	
    assign axi_slv_inf.BREADY  = axi_mas_inf.BREADY;
	
    assign axi_slv_inf.ARID    = axi_mas_inf.ARID;
    assign axi_slv_inf.ARADDR  = axi_mas_inf.ARADDR;
    assign axi_slv_inf.ARLEN   = axi_mas_inf.ARLEN;
    assign axi_slv_inf.ARSIZE  = axi_mas_inf.ARSIZE;
    assign axi_slv_inf.ARBURST = axi_mas_inf.ARBURST;
    assign axi_slv_inf.ARVALID = axi_mas_inf.ARVALID;
	
    assign axi_slv_inf.RREADY  = axi_mas_inf.RREADY;


    initial begin 
        uvm_config_db #(virtual axi_mas_inf #(`MAS_ADDR_W,`MAS_DATA_W))::set(null,"uvm_test_top.env_h.mas_agent_h","vinf",axi_mas_inf);
        uvm_config_db #(virtual axi_slv_inf #(`SLV_ADDR_W,`SLV_DATA_W))::set(null,"uvm_test_top.env_h.slv_agent_h","vinf",axi_slv_inf);
        run_test("");
    end
endmodule

`endif
