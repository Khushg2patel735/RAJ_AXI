`ifndef AXI_MAS_SEQS_SV
`define AXI_MAS_SEQS_SV

class axi_mas_seqs #(parameter ADDR_WIDTH=32,parameter DATA_WIDTH=32) extends axi_mas_base_seqs #(32,32);
  `uvm_object_param_utils(axi_mas_seqs)

  axi_mas_seqs_item #(32, 32) write_trans;
  axi_mas_seqs_item #(32, 32) read_trans;
  bit [`ADDR_WIDTH-1:0] addr_que[$];   // addresses already written, oldest at the back

  function new(string name = "axi_mas_seqs #(parameter ADDR_WIDTH=32,parameter DATA_WIDTH=32)");
    super.new(name);
  endfunction

  task body();
    `uvm_info(get_full_name(), "MAS_SEQS BODY started", UVM_DEBUG)  // YES 1
    repeat (5) begin
      fork
      write();
     // read();
      join// both directions actually driven now
    end
    `uvm_info(get_full_name(), "MAS_SEQS BODY ENDED", UVM_DEBUG)
  endtask


  task write();
                          `uvm_info(get_full_name(), "AXI_MAS_WRITE_SEQS started", UVM_DEBUG) // YES 2
     `uvm_create(write_trans)
                          // write_trans = axi_mas_seqs_item #(32, 32)::type_id::create("write_trans");
                          `uvm_info(get_full_name(),"BEFORE MASTER SEQS WRITE METHOD STARTED",UVM_DEBUG)  // YES 3
     start_item(write_trans);
                          `uvm_info(get_full_name(),"AFETR MASTER SEQS WRITE METHOD STARTED",UVM_DEBUG)   // YES 4

     if (!write_trans.randomize() with {trans_type == axi_mas_seqs_item #(32,32)::MAS_WRITE;AWID inside {[0:15]};AWADDR inside {[20:100]};AWLEN == 3 /*inside {[0:3]}*/;AWSIZE == 2/* inside {[0:2]}*/;AWBURST inside {[0:3]};})
                                                             `uvm_fatal("WR_ADDR", "randomization fail")

                                                             `uvm_info(get_full_name(),$sformatf("BEFORE AWADDR = %0d",write_trans.AWADDR),UVM_MEDIUM)//  ok
     addr_que.push_back(write_trans.AWADDR);   // record the address for a later read()
                                                             `uvm_info(get_full_name(),$sformatf("BEFORE AWADDR = %0d",write_trans.AWADDR),UVM_MEDIUM)//  ok
    `uvm_info(get_full_name(),write_trans.sprint(),UVM_MEDIUM) // write_trans.print();

                                                            //   `uvm_info(get_full_name(),"BEFORE MASTER SEQS WRITE METHOD ENDED",UVM_MEDIUM) //ok
     finish_item(write_trans);
                                                            `uvm_info(get_full_name(),"AFETR MASTER SEQS WRITE METHOD ENDED",UVM_MEDIUM)// ok 
                                                            `uvm_info(get_full_name(), "AXI_MAS_WRITE_SEQS ENDED", UVM_MEDIUM)
  endtask




  task read();
                          `uvm_info(get_full_name(), "AXI_MAS_READ_SEQS STARTED", UVM_DEBUG)
                                                     // if (addr_que.size() != 0) begin
                                                   //`uvm_warning("RD_ADDR", "no previously written address available to read - skipping")
                                                  // return;
                                                    //end

                                                  // else begin
                                                 // bit [`ADDR_WIDTH-1:0] target_addr;
                                                   //   target_addr = addr_que.pop_front();   // popped once, safely, before randomize
        `uvm_create(read_trans);
                                                 //  write_trans = axi_mas_seqs_item #(32, 32)::type_id::create("write_trans");
      start_item(read_trans);
                          `uvm_info(get_full_name(),read_trans.sprint(),UVM_MEDIUM)

                                             // ARADDR is pinned to a previously written address (not left to randomize);
                                             // everything else about the read is still randomized within the constraint.
                               //  if (!rsp.randomize() with {trans_type == axi_mas_seqs_item #(32,32)::MAS_READ;ARID   inside {[0:15]};ARADDR inside {[10:50]};})
     if(!read_trans.randomize() with {trans_type == axi_mas_seqs_item #(32,32)::MAS_READ;ARID inside {[0:10]};ARADDR inside {[10:20]};ARLEN == 3 /*inside {[0:3]}*/;ARSIZE == 2/* inside {[0:2]}*/;ARBURST inside {[0:1]};})
     `uvm_fatal("RD_ADDR", "randomization fail")


     
     //write_trans.print();
        

               // `uvm_info("*****AXI_MAS_SEQUENCE RANDOMIZE DATA*****",$sformatf("REQUEST RECEIVED: ARID=%0d ARADDR=%0h ARLEN = %0d ARBURST =%0d ARSIZE = %0d",write_trans.ARID,write_trans.ARADDR,write_trans.ARLEN,write_trans.ARBURST,write_trans.ARSIZE),UVM_LOW)
                                              //addr_que.push_back(write_trans.ARID,write_trans.ARADDR,write_trans.ARLEN,write_trans.ARSIZE,write_trans.ARBURST);  
                                                    // record the address for a later read()
     finish_item(read_trans);
                          `uvm_info(get_full_name(),read_trans.sprint(),UVM_MEDIUM)

                          `uvm_info(get_full_name(), "AXI_MAS_READ_SEQS ENDED", UVM_DEBUG)
  endtask




endclass
`endif
    





/*
`ifndef AXI_MAS_SEQS_SV
`define AXI_MAS_SEQS_SV

class axi_mas_seqs extends axi_mas_base_seqs;

    `uvm_object_utils(axi_mas_seqs)

    axi_mas_seqs_item #(32,32) write_trans;

    bit [`ADDR_WIDTH-1 :0]addr_que[$];

    function new(string name = "axi_mas_seqs");
      super.new(name);
    endfunction
    
    task body();
      `uvm_info(get_full_name(),"AXI_MAS_SEQS BODY started",UVM_LOW);
       repeat(10)begin
        write_trans = axi_mas_seqs_item #(32,32)::type_id::create("write_trans");
          write();
      end
      `uvm_info(get_full_name(),"AXI_MAS_SEQS BODY ENDED",UVM_LOW);
    endtask


    task write();
      `uvm_info(get_full_name(),"AXI_MAS_WRITE_SEQS started",UVM_LOW);
      start_item(write_trans);
      `uvm_info("mas_seqs","--------AXI_MAS_SEQS---------",UVM_LOW)
      if(!write_trans.randomize() with {AWID inside {[0:15]};AWADDR inside {[20:100]};})
      `uvm_fatal("WR_ADDR","randomization fail")

    addr_que.push_front(AWADDR);

      write_trans.print();
      finish_item(write_trans);
      `uvm_info(get_full_name(),"AXI_MAS_WRITE_SEQS ENDED",UVM_LOW);
    endtask
   
    task read();
      `uvm_info(get_full_name(),"AXI_MAS_READ_SEQS started",UVM_LOW);
        start_item(reg);
        `uvm_info(get_full_name(),"READ_SEQUENCE_STARTED",UVM_LOW)

        write_trans.ARADDR = addr_que.pop_back();

        `uvm_info(get_full_name(),"READ_SEQUENCE_ENDED",UVM_LOW)
        finish_item(write_trans);
      `uvm_info(get_full_name(),"AXI_MAS_READ_SEQS ENDED",UVM_LOW);
    endtask

endclass
`endif
*/
