`ifndef AXI_SLV_READ_SEQS_SV
`define AXI_SLV_READ_SEQS_SV

class axi_slv_read_seqs extends axi_slv_base_seqs;

   //  bit [`DATA_WIDTH-1:0] slv_mem [bit [`ADDR_WIDTH-1:0]];

  `uvm_object_utils(axi_slv_read_seqs)

  axi_mas_seqs_item #(32, 32) req;
  
  `uvm_declare_p_sequencer(axi_slv_seqr #(`ADDR_WIDTH, `DATA_WIDTH))


  function new(string name = "axi_slv_read_seqs");
   super.new(name);
  endfunction

  task body();
       
    axi_slv_seqs_item #(`ADDR_WIDTH,`DATA_WIDTH) item;
    axi_slv_seqs_item #(`ADDR_WIDTH,`DATA_WIDTH) rsp;
                                                        `uvm_info(get_full_name(),"============SLV SEQS BODY METHOD CALL===============",UVM_MEDIUM)
      forever begin
                                                         `uvm_info(get_full_name(),"=======================BEFORE==================",UVM_MEDIUM)
       p_sequencer.mon_fifo.get(item);
                                                        `uvm_info(get_full_name(),"=======================AFTER===================",UVM_MEDIUM)
                                                        `uvm_info("SLV_SEQ",$sformatf("REQUEST RECEIVED: AWID=%0d AWADDR=%0h RDATA=%0p",item.AWID,item.AWADDR,item.RDATA),UVM_MEDIUM)

     //-----------------WRITE RESPONSE------------
     if(item.trans_type == axi_slv_seqs_item #(`ADDR_WIDTH,`DATA_WIDTH)::SLV_READ)begin
                                                        //if(req.slv_trans_type_e == axi_slv_seqs_item ::SLV_WRITE)begin
                                                        //createing response transection
         rsp = axi_slv_seqs_item #(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create("rsp");
                                                        //rsp = axi_slv_seqs_item ::type_id::create("rsp");
                                                        //B-channel response
         rsp.set_id_info(item);                         //Keeps sequence and transaction IDs aligned
         rsp.RID   = item.RID;
         rsp.RDATA = item.RDATA;
         rsp.RLAST = item.RLAST;
         rsp.RRESP = 2'b00;
                                                         `uvm_info(get_full_name(),"SLV RESPONE SEQS BEFORE START_ITEM",UVM_LOW)
         start_item(rsp);
                                                         `uvm_info(get_full_name(),"SLV RESPONE SEQS AFTER START_ITEM",UVM_LOW)
                                                          //start_item(req);
                                                         `uvm_info(get_full_name(),"SLV RESPONSE SEQS BEFORE FINISH_ITEM",UVM_LOW)
        finish_item(rsp);
                                                         `uvm_info(get_full_name(),"SLV RESPONSE SEQS AFTER FINISH_ITEM",UVM_LOW)
      end
    end
  endtask
endclass
`endif
