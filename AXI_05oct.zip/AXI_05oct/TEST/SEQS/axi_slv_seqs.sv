//======================================================================
// File Name      : axi_slv_seqs.sv
// Module Name    : axi_slv_seqs
// Project        : AXI_05oct
// Author         : Rajkumar chaurasiya
// Created On     : 2026-09-10 16:51:07
// Last Modified  : 2026-10-09 12:19:01
// Language       : SystemVerilog
// Description    :
// Functionality  :
// Ports          :
// Notes          :
//======================================================================

`ifndef AXI_SLV_SEQS_SV
`define AXI_SLV_SEQS_SV

class axi_slv_seqs #(parameter ADDR_WIDTH = 32,parameter DATA_WIDTH = 32) extends axi_slv_base_seqs #(.ADDR_WIDTH(ADDR_WIDTH),.DATA_WIDTH(DATA_WIDTH));

  // Associative array memory model
  bit [DATA_WIDTH-1:0] slv_mem [bit [ADDR_WIDTH-1:0]];

  `uvm_object_param_utils(axi_slv_seqs #(ADDR_WIDTH, DATA_WIDTH))

  `uvm_declare_p_sequencer(axi_slv_seqr #(ADDR_WIDTH, DATA_WIDTH))

  function new(string name = "axi_slv_seqs");
    super.new(name);
  endfunction

  task body();
                                               `uvm_info(get_full_name(), "============ SLV SEQS BODY STARTED ============", UVM_DEBUG)
      reads();
                                               `uvm_info(get_full_name(), "============ SLV SEQS BODY ENDED ============", UVM_DEBUG)
  endtask


  //------------------------------------------------------------------
  // WRITE RESPONSE HANDLER TASK
  //------------------------------------------------------------------

/*
task writes();
    axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) write_item;
    axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) write_rsp;
     // `uvm_create(read_item)

    forever begin
                                                                             // Fetch write transaction from the write monitor FIFO
      p_sequencer.write_mon_fifo.get(write_item);
                                                                            `uvm_info("SEQUECE BID_DEBUG RECEIVE",write_item.sprint(),UVM_DEBUG)
      if (write_item.trans_type == axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_WRITE) begin
        // Update local memory
        slv_mem[write_item.AWADDR] = write_item.WDATA;

        // Create Write Response item (B channel)
        write_rsp = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::type_id::create("write_rsp");
        
        write_rsp.trans_type = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_WRITE;
        write_rsp.BID   = write_item.AWID;
                                                                    `uvm_info(get_full_name(),$sformatf("AFTER WRITE_TRANSE  = %0d",write_rsp.BID),UVM_DEBUG)//  ok
        write_rsp.BRESP = 2'b00; // OKAY response
                                                                    `uvm_info("SEQUECE BID_DEBUG SEND",write_rsp.sprint(),UVM_DEBUG)
        start_item(write_rsp);
       // finish_item();
        finish_item(write_rsp);
      end
    end
  endtask
*/

  //------------------------------------------------------------------
  // READ RESPONSE HANDLER TASK
  //------------------------------------------------------------------
  
  
  task reads();

  axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) read_item;
  axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) read_rsp;
  bit [ADDR_WIDTH-1:0] current_addr;

  forever begin
    // Get READ request from monitor
    p_sequencer.read_mon_fifo.get(read_item);
                                   `uvm_info("ARID_DEBUG",read_item.sprint(),UVM_DEBUG)
    // Create READ response
    read_rsp = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::type_id::create("read_rsp");

    if (!read_rsp.randomize() with {trans_type == axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_READ;read_rsp.ARLEN == read_item.ARLEN;}) begin
        `uvm_fatal("RDATA_RANDOMIZE","Failed to randomize read response")
    end
    current_addr = read_item.ARADDR;
                                     `uvm_info("ARID_DEBUG",$sformatf("ARID_DEBUG=%0h", read_item.ARID),UVM_DEBUG)
    // Response fields
   // read_rsp.ARID  = read_item.ARID;
    read_rsp.RID   = read_item.ARID;
   // read_rsp.RID = read_item.ARID;
    `uvm_info("RID_GENERATION",
                               $sformatf("READ RESPONSE: READ_ITEM_ARID=%0h ==> RESPONSE_RID=%0h",read_item.ARID,read_rsp.RID),UVM_MEDIUM)
    
    //read_rsp.ARLEN = read_item.ARLEN;
  /*
    foreach(read_item.RDATA[i])begin
     read_rsp.RDATA[i] = read_item.RDATA[i];
    read_rsp.RLAST = 1'b1;
   // read_rsp.RLAST = read_item.ARLEN;//SAME RLAST AA RHA PR ARLEN k according data nhi aa rha h 
   end      
   */
    read_rsp.RRESP = 2'b00;
    //read_rsp.RLAST = 1'b1;
                                       `uvm_info("ARID_DEBUG",read_rsp.sprint,UVM_MEDIUM)
    // Send response to slave driver
    start_item(read_rsp);
    finish_item(read_rsp);

  end

endtask
endclass

`endif

