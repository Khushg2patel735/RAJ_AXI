`ifndef AXI_MAS_TEST_SV
`define AXI_MAS_TEST_SV

class axi_mas_test extends axi_mas_base_test;

    `uvm_component_utils(axi_mas_test);

    axi_mas_seqs #(32,32)  mas_seqs;

    axi_slv_seqs #(32,32) slv_seqs;
    

    function new(string name = "axi_mas_test",uvm_component parent = null);
      super.new(name,parent);
    endfunction 

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
        mas_seqs = axi_mas_seqs #(32,32)::type_id::create("mas_seqs");
        slv_seqs = axi_slv_seqs #(32,32)::type_id::create("slv_seqs");
      
    endfunction 


    task run_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_MAS_TEST_RUN_PHASE_STARTED",UVM_MEDIUM);
      phase.raise_objection(this);
                                                            `uvm_info(get_full_name(),"Before START THE SEQS OF MAS TEST",UVM_MEDIUM)
        fork
       mas_seqs.start(env_h.mas_agent_h[0].mas_seqr_h);
                                                            `uvm_info(get_full_name(),"After START THE SEQS OF MAS TEST",UVM_MEDIUM)
       slv_seqs.start(env_h.slv_agent_h[0].slv_seqr_h);//
                                                            `uvm_info(get_full_name(),"*********BEFORE MAX TIME RAECH*******",UVM_MEDIUM)
        join_none

         #2000;

      phase.drop_objection(this);
                                                            `uvm_info(get_full_name(),"AXI_MAS_TEST_RUN_PHASE_ENDED",UVM_MEDIUM);
    endtask



endclass
`endif


