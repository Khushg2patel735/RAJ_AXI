`ifndef AXI_MAS_BASE_TEST_SV
`define AXI_MAS_BASE_TEST_SV

class axi_mas_base_test extends uvm_test;
  `uvm_component_utils(axi_mas_base_test)
  axi_env env_h;
  axi_env_config axi_env_cfg;

    function new(string name = "axi_mas_base_test",uvm_component parent);
      super.new(name,parent);

    endfunction 


    function void build_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_MAS_BASE_TEST build_phase STARTED",UVM_DEBUG);
      super.build_phase(phase);
      env_h = axi_env::type_id::create("env_h",this);
      axi_env_cfg = axi_env_config::type_id::create("axi_env_cfg",this);
      if(!uvm_config_db#(virtual axi_mas_intf #(`ADDR_WIDTH,`DATA_WIDTH))::get(null,"","MAS_INTF",axi_env_cfg.mas_intf))begin
     `uvm_fatal(get_full_name(),"AXI MASTER IS NOT GETTING");
     end

     if(!uvm_config_db#(virtual axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH))::get(null,"","slv_intf",axi_env_cfg.slv_intf))begin
     `uvm_fatal(get_full_name(),"AXI SLAVE NOT GETTING");
     end

        axi_env_cfg.no_of_mas_agent = 1;
        axi_env_cfg.no_of_slv_agent = 1;
      axi_env_cfg.create_sub_config();
/*
      axi_env_cfg.axi_m_agent_config = new[axi_env_cfg.no_of_mas_agent];// 2 axi_m_agent_config[0] // axi_m_agent_config[1]
     axi_env_cfg.axi_m_agent_config[0] = axi_mas_agent_config::type_id::create("axi_env_cfg.axi_m_agent_config",this);
     axi_env_cfg.axi_s_agent_config = new[axi_env_cfg.no_of_slv_agent];
     axi_env_cfg.axi_s_agent_config[0] = axi_slv_agent_config::type_id::create("axi_env_cfg.axi_s_agent_config",this);
     
     axi_env_cfg.axi_m_agent_config[0].mas_intf = axi_env_cfg.mas_intf;
     axi_env_cfg.axi_s_agent_config[0].slv_intf = axi_env_cfg.slv_intf;
      
      $display("before set config is active = %0d",axi_env_cfg.axi_m_agent_config[0].is_active); 
      */
      
      uvm_config_db#(axi_env_config)::set(this,"*","AXI_ENV_CONFIG",axi_env_cfg);
      
      $display("after set config is active = %0d",axi_env_cfg.axi_m_agent_config[0].is_active);
      
      //`uvm_fatal(get_full_name(),"AXI_BASE_TEST_BUILD_PHASE")
    `uvm_info(get_full_name(),"AXI_MAS_BASE_TEST build_phase ENDED",UVM_DEBUG);
      
    endfunction 

    function void end_of_elaboration_phase(uvm_phase phase);
      super.end_of_elaboration_phase(phase);
      uvm_top.print_topology();

    endfunction 

endclass
`endif









/*
`ifndef AXI_MAS_BASE_TEST_SV
`define AXI_MAS_BASE_TEST_SV

class axi_mas_base_test extends uvm_test;
  
  `uvm_component_utils(axi_mas_base_test)

    axi_env env_h;

    function new(string name = "axi_mas_base_test",uvm_component parent);
      super.new(name,parent);

    endfunction 


    function void build_phase(uvm_phase phase);
      super.build_phase(phase);

      env_h = axi_env::type_id::create("env_h",this);

    endfunction 

    function void end_of_elaboration_phase(uvm_phase phase);
      super.end_of_elaboration_phase(phase);
      uvm_top.print_topology();

    endfunction 



endclass
`endif
*/
