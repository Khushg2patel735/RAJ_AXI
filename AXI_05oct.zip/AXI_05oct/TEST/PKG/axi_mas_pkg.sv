// Create Date    : 29-07-2026
// Last Modifiey  : 
// File Name   	  : axi_mas_pkg.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////


`ifndef AXI_MAS_PKG_SV
`define AXI_MAS_PKG_SV

  `include "uvm_macros.svh" 
  `include "axi_mas_intf.sv"

package axi_mas_pkg;

   import uvm_pkg::*;

  `include "axi_mas_define.sv"
  `include "axi_mas_agent_config.sv"

  `include "axi_mas_seqs_item.sv"
  `include "axi_mas_drv.sv"
  `include "axi_mas_mon.sv"
  `include "axi_mas_seqr.sv"
  `include "axi_mas_agent.sv"

  `include "axi_mas_base_seqs.sv"



endpackage 
`endif
