// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : axi_slv_pkg.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////


`ifndef AXI_SLV_PKG_SV
`define AXI_SLV_PKG_SV

   `include "uvm_macros.svh" 
`include "axi_slv_intf.sv"
   
package axi_slv_pkg;

    import uvm_pkg::*;

  `include "axi_slv_define.sv"
  `include "axi_slv_agent_config.sv"

  `include "axi_slv_seqs_item.sv"
  `include "axi_slv_drv.sv"
  `include "axi_slv_mon.sv"
  `include "axi_slv_seqr.sv"
  `include "axi_slv_agent.sv"

  `include "axi_slv_base_seqs.sv"



endpackage 
`endif
