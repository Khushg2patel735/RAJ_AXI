// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_test_pkg.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////


`ifndef AXI_TEST_PKG_SV
`define AXI_TEST_PKG_SV

//`include "axi_env_pkg.sv"
`include "axi_mas_define.sv"
`include "axi_slv_define.sv"


package axi_test_pkg;

  `include "uvm_macros.svh"
 // `include "uvm_macros.svh"
  import uvm_pkg::*;
  import axi_mas_pkg::*;
  import axi_slv_pkg::*;
  import axi_env_pkg::*;

  `include "axi_mas_seqs.sv"

  `include "axi_slv_seqs.sv"
//  `include "axi_slv_read_seqs.sv"

  `include "axi_mas_base_test.sv"

   `include "axi_mas_test.sv"


endpackage
`endif
