// Create Date    : 29-07-2026
// Last Modifiey  : 
// File Name   	  : axi_env_pkg.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////


`ifndef AXI_ENV_PKG_SV
`define AXI_ENV_PKG_SV

`include "axi_mas_pkg.sv"
`include "axi_slv_pkg.sv"

 
package axi_env_pkg;

  `include "uvm_macros.svh"
  import uvm_pkg::*;

  import axi_mas_pkg::*;
  import axi_slv_pkg::*;
  `include "axi_env_config.sv"


  `include "axi_env.sv"
 

endpackage
`endif
