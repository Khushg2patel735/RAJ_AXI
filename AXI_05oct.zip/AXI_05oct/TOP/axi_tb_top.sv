/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 29-07-2026
// Last Modifiey  : 
// File Name   	  : axi_tb_top.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
/////////////////////////////////////////////////////////////////////////

`ifndef AXI_TB_TOP_SV
`define AXI_TB_TOP_SV


`include "uvm_macros.svh"
//import uvm_pkg::*;

`include "axi_mas_define.sv"
`include "axi_mas_intf.sv"
//`include "axi_slv_intf.sv"

`include "axi_test_pkg.sv"

module axi_tb_top;
  
  import uvm_pkg::*;
  import axi_test_pkg::*;

  logic ACLK;
  logic ARESETn;

  // AXI MASTER INTERFACE .....
  axi_mas_intf #(`ADDR_WIDTH,`DATA_WIDTH) mas_intf(ACLK,ARESETn);

  // AXI SLAVE INTERFACE .....
  axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH) slv_intf(ACLK,ARESETn);

//================ Write Address Channel ================

  assign slv_intf.AWID    = mas_intf.AWID  ;
  assign slv_intf.AWADDR  = mas_intf.AWADDR ;
  assign slv_intf.AWLEN   = mas_intf.AWLEN;
  assign slv_intf.AWSIZE  = mas_intf.AWSIZE;
  assign slv_intf.AWVALID = mas_intf.AWVALID;

  assign mas_intf.AWREADY = slv_intf.AWREADY; 

//================ Write Data Channel ===================
  
  assign slv_intf.WID     =  mas_intf.WID ;
  assign slv_intf.WDATA   =  mas_intf.WDATA;
  assign slv_intf.WSTRB   =  mas_intf.WSTRB;
  assign slv_intf.WLAST  =  mas_intf.WLAST;
  assign slv_intf.WVALID  =  mas_intf.WVALID;

  assign mas_intf.WREADY  =  slv_intf.WREADY; 


//================ Write Response Channel ===============
 
  assign slv_intf.BREADY  = mas_intf.BREADY;

  assign mas_intf.BID     = slv_intf.BID; 
  assign mas_intf.BRESP   = slv_intf.BRESP; 
  assign mas_intf.BVALID  = slv_intf.BVALID; 


 //================ Read Address Channel =================
  
  assign slv_intf.ARID    = mas_intf.ARID;
  assign slv_intf.ARADDR  =  mas_intf.ARADDR ;
  assign slv_intf.ARLEN   =  mas_intf.ARLEN;
  assign slv_intf.ARSIZE  = mas_intf.ARSIZE;
  assign slv_intf.ARVALID =  mas_intf.ARVALID ;

  assign mas_intf.ARREADY = slv_intf.ARREADY; 


  
//================ Read Data Channel ====================

   
  assign slv_intf.RREADY = mas_intf.RREADY;
 
  assign mas_intf.RID    = slv_intf.RID; 
  assign mas_intf.RDATA  = slv_intf.RDATA ; 
  assign mas_intf.RRESP  = slv_intf.RRESP; 
  assign mas_intf.RLAST  = slv_intf.RLAST ; 
  assign mas_intf.RVALID = slv_intf.RVALID ; 


 // axi_mas_intf #(.ADDR_WIDTH(32),.DATA_WIDTH(32)) inf (.ACLK(ACLK));
   
  // clock genration 
    initial begin 
      ACLK = 0;
        forever #5 ACLK = ~ACLK;
     end

  initial begin 
    ARESETn = 0;
   // mas_intf.AWVALID = 1'b0;
   // mas_intf.WVALID = 1'b0;
  //  slv_intf.BVALID = 1'b0;
    #5 ARESETn = 1;
  end
  initial begin 
    $dumpfile("dump.vcd");
    $dumpvars;
  end
    initial begin
      uvm_config_db #(virtual axi_mas_intf #(`ADDR_WIDTH,`DATA_WIDTH))::set(null,"*","MAS_INTF",mas_intf);
      uvm_config_db #(virtual axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH))::set(null,"*","slv_intf",slv_intf); 
    //  uvm_config_db #(virtual axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH))::set(null,"*","vinf_m",mas_intf); 
   //   uvm_config_db #(virtual axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH))::set(null,"*","vinf_m",slv_intf); 
        run_test("axi_mas_test");
    end

endmodule
`endif

