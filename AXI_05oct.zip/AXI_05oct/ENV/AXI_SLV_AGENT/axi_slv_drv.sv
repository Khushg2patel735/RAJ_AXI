/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : axi_slv_drv.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////

`ifndef AXI_SLV_DRV_SV
`define AXI_SLV_DRV_SV

class axi_slv_drv #(parameter ADDR_WIDTH=32,DATA_WIDTH=32) extends uvm_driver #(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH));
  
  `uvm_component_param_utils(axi_slv_drv #(ADDR_WIDTH,DATA_WIDTH))

    axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) b_resp_q[$];
    axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) rd_data_q[$];

    virtual axi_slv_intf #(ADDR_WIDTH,DATA_WIDTH) slv_intf;


    function new(string name = "axi_slv_drv",uvm_component parent);
      super.new(name,parent);
   endfunction


   function void build_phase(uvm_phase phase);
                                        `uvm_info(get_full_name(),"AXI_SLV_DRV build_phase STARTED",UVM_DEBUG);
     super.build_phase(phase);
                                           // if(!uvm_config_db #(virtual axi_slv_intf #(ADDR_WIDTH,DATA_WIDTH))::get(this," ","vinf_d",slv_intf))
                                           //`uvm_fatal("get_not found in the range","did_not_find axi_mas_intf")
                                        `uvm_info(get_full_name(),"AXI_SLV_DRV build_phase ENDED",UVM_DEBUG);
   endfunction : build_phase

//--------------------------------RUN_PHASE-------------------------------------   
   task run_phase(uvm_phase phase);
                                        `uvm_info(get_full_name(),"SLV_DRV RUN_PHASE STARTED",UVM_DEBUG);
     fork
    forever begin                       // forever khatam nhi hoga so driver never call in this case
         seq_item_port.get(req);                               `uvm_info(get_full_name(),"get_net_item started",UVM_MEDIUM)    // YES 3
     // seq_item_port.get_next_item(req);
                                        `uvm_info(get_full_name(),"SlV GET_NEXT_ITEM CALL ENDed",UVM_DEBUG)

       // b_resp_q.push_back(req);
       // b_resp_q.push_back
    //   fork
       if (req.trans_type == axi_slv_seqs_item #(32,32)::SLV_WRITE)begin 
         
          b_resp_q.push_back(req);
        end
        
       if (req.trans_type == axi_slv_seqs_item #(32,32)::SLV_READ)begin 
          rd_data_q.push_back(req);
        end
      //  join_none

      //  rd_data_q.push_back(axi_slv_seqs_item #(32,32)::SLV_READ);
                                        `uvm_info("SLV_DRV",$sformatf("RESPONSE RECEIVED: BID=%0d BRESP=%0d",req.BID,req.BRESP),UVM_DEBUG);

       // seq_item_port.item_done();
      end
      join_none

    fork
       addr_write();
       data_write();
       b_resp_channel();
       rd_addr_channel();
       rd_data();
    join

   endtask

/*
    task driver();
      fork
        addr_write();
        data_write();
     //   resp_write();
 //       rd_addr();
   //     rd_data();

      join
    `uvm_info(get_full_name(),"AXI_SLV_DRV run_phase ENDED",UVM_MEDIUM);
    endtask
    */

//-------------------------------WRITE_ADDRESS_CHANNEL--------------------------
    task addr_write();
      forever begin
                                                                          `uvm_info(get_full_name(),"axi slv drv STARTED addr_write",UVM_DEBUG)   //YES 1
        @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.AWVALID);
                                                                          `uvm_info(get_full_name(),"axi slv drv ENDEd addr_write",UVM_DEBUG)        // YES
          slv_intf.axi_slv_drv_cb.AWREADY <= 1'b1;
      end
    endtask

//------------------------------WRITE_DATA_CHANNEL----------------------------    

    task data_write();
      forever begin
          @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.WVALID);
          slv_intf.axi_slv_drv_cb.WREADY <= 1'b1;
      end
    endtask

//-----------------------------WRITE_RESPONSE_CHANNEL------------------------    
   // task (axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH)rsp);//formal argument vs actual argument ka concept hai.
    task b_resp_channel();
        axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) b_resp_h;
         forever begin
           @(slv_intf.axi_slv_drv_cb);
           wait(b_resp_q.size() != 0);
          // wait(b_resp_q.size() > 0);
             b_resp_h = b_resp_q.pop_front();
                                       `uvm_info("BID_DEBUG",b_resp_h.sprint,UVM_DEBUG)
                                       //`uvm_info(get_full_name(),sprint("SLAVE_Driver B response : BID = %0d BRESP = %0d",b_resp_h.BID,b_resp_h.BRESP),UVM_NONE)
                                       //`uvm_info(get_full_name(),$sformatf("SLAVE_Driver B response : BID = %0d BRESP = %0d",b_resp_h.BID,b_resp_h.BRESP),UVM_NONE)
                                      // `uvm_info(get_full_name(),"BVALID assert",UVM_DEBUG)
                                                           //`uvm_info(get_full_name(),$sformatf("Driver B response : BID = %0d BRESP = %0d",rsp.BID,rsp.BRESP),UVM_DEBUG)
  // repeat(3)@(slv_intf.axi_slv_drv_cb);

    // @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.WLAST);// && slv_intf.axi_slv_drv_cb.BREADY);
    // if(slv_intf.axi_slv_drv_cb.WLAST)begin
    // @(slv_intf.axi_slv_drv_cb);
      slv_intf.axi_slv_drv_cb.BID      <= b_resp_h.BID;
      slv_intf.axi_slv_drv_cb.BRESP    <= b_resp_h.BRESP;
      slv_intf.axi_slv_drv_cb.BVALID   <= 1'b1;
                                       `uvm_info("BID_DEBUG",b_resp_h.sprint,UVM_DEBUG)
                                                        //  `uvm_info(get_full_name(),$sformatf("SLAVE_Driver B response : BID = %0d BRESP = %0d",b_resp_h.BID,b_resp_h.BRESP),UVM_NONE)
                                                       //    `uvm_info(get_full_name(),"BVALID assert",UVM_DEBUG)
                                                         // `uvm_info(get_full_name(),$sformatf("SLAVE_Driver B response : BID = %0d BRESP = %0d",b_resp_h.BID,b_resp_h.BRESP),UVM_NONE)
                                                          // `uvm_info(get_full_name(),"BVALID assert",UVM_DEBUG)
      //@(slv_intf.axi_slv_drv_cb  iff slv_intf.axi_slv_drv_cb.BREADY);
                                                           `uvm_info(get_full_name(),"B CHANNEL HANDSHAKING COMPLETED",UVM_DEBUG)
    //  @(slv_intf.axi_slv_drv_cb);
      //slv_intf.axi_slv_drv_cb.BID <= 1'b0;
     // slv_intf.axi_slv_drv_cb.BVALID <= 1'b0;
     //  end
     end

    endtask

// ----------------------------READ_ADDRESS_CHANNEL------------------------------

    task rd_addr_channel();
         forever begin
                                                                     `uvm_info(get_full_name(),"axi slv drv STARTED addr_write",UVM_MEDIUM)   //YES 1

       @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.ARVALID);
                                                                      `uvm_info(get_full_name(),"axi slv drv ENDEd addr_write",UVM_DEBUG)        // YES
          slv_intf.axi_slv_drv_cb.ARREADY <= 1'b1;

        // `uvm_info("ARID_DEBUG",slv_intf.sprint(),UVM_DEBUG)
        
          //`uvm_info("SLV_DRV_AR_CHANNEL ARID_DEBUG",$sformatf("SLV_DRIVER_K_PASS_INTERFACE_SE_HO_K  ARID_DEBUG = %0d | ARLEN = %0d",slv_intf.axi_slv_drv_cb.ARID,slv_intf.axi_slv_drv_cb.ARLEN),UVM_DEBUG)
      end
    endtask

 //----------------------------READ_DATA_CHANELL------------------------------    

    task rd_data();
       axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) rd_trans_h;
                                                      `uvm_info(get_full_name(),"SLV_DRIVER_RD_DATA_CHANNEL STARTED",UVM_LOW);
         forever begin
           //  @(slv_intf.axi_slv_drv_cb);                                                //  for(int i = 0;i<wr_trans_data.AWLEN+1;i++)begin
           wait(rd_data_q.size() != 0);
          rd_trans_h = rd_data_q.pop_front();

        `uvm_info("Inside_the_queue ARID_DEBUG",rd_trans_h.sprint(),UVM_MEDIUM)

         // `uvm_info("slv_drv_rd_channel",$sformatf("SLV_DRIVER_ME_PACKET_LETE_TIME  RID_DEBUG = %0d |ARID = %0d | ARLEN = %0d | RDATA_SIZE = %0d",rd_trans_h.RID,rd_trans_h.ARID,rd_trans_h.ARLEN,rd_trans_h.RDATA.size()),UVM_DEBUG)
             
            // @(slv_intf.axi_slv_drv_cb);                                                //  for(int i = 0;i<wr_trans_data.AWLEN+1;i++)begin
        foreach(rd_trans_h.RDATA[i])begin
             slv_intf.axi_slv_drv_cb.RID <= rd_trans_h.RID;
                                                                              // slv_intf.axi_slv_drv_cb.RDATA <= rd_trans_h.RDATA;
             slv_intf.axi_slv_drv_cb.RDATA <= rd_trans_h.RDATA[i];
             //slv_intf.axi_slv_drv_cb.RRESP <= rd_trans_h.RRESP;
           //  slv_intf.axi_slv_drv_cb.RVALID <= 1'b1;

           // slv_intf.axi_slv_drv_cb.RLAST <= (i == rd_trans_h.ARLEN+1);//? 1:0;//RLAST nhi AYEGA
           // slv_intf.axi_slv_drv_cb.RLAST <= (i == rd_trans_h.RDATA.size()-1);// ? 1:0;//RLAST AAYEGA ISSE
             slv_intf.axi_slv_drv_cb.RRESP <= rd_trans_h.RRESP;
            // slv_intf.axi_slv_drv_cb.RLAST <= (i == rd_trans_h.RDATA.size()-1);
             slv_intf.axi_slv_drv_cb.RVALID <= 1'b1;
                                                                               //  slv_intf.axi_slv_drv_cb.RLAST <= (i == rd_trans_h.RDATA.size());
            slv_intf.axi_slv_drv_cb.RLAST <= (i == rd_trans_h.ARLEN+1) ? 1:0;//SAME RLAST AA RHA PR ARLEN k according data nhi aa rha h 

            // slv_intf.axi_slv_drv_cb.RVALID <= 1'b1;
              @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.RREADY);

         // `uvm_info("slv_drv_rd_channel",$sformatf("SLV_DRIVER_ME_RREADY_K_BAAAD  RID_DEBUG = %0d |ARID = %0d | ARLEN = %0d | RDATA_SIZE = %0d",rd_trans_h.RID,rd_trans_h.ARID,rd_trans_h.ARLEN,rd_trans_h.RDATA.size()),UVM_MEDIUM)
            // slv_intf.axi_slv_drv_cb.RLAST <= (i == rd_trans_h.ARLEN) ? 1'b1:1'b0;
           //  slv_intf.axi_slv_drv_cb.RVALID <= 1'b1;
                //end
            //  @(slv_intf.axi_slv_drv_cb iff (slv_intf.axi_slv_drv_cb.RREADY));
            // DRIVER ME RLAST PE KOI CONTROL KREGA YA SEQUENCE KHUD RLAST GENRATE KR K BHEJEGA
            if(rd_data_q.size() == 0)begin
              slv_intf.axi_slv_drv_cb.RLAST <= 1'b0;
              slv_intf.axi_slv_drv_cb.RVALID <= 1'b0;
            end
            //@(slv_intf.axi_slv_drv_cb);
            //end // foreach
            //`uvm_info(get_full_name(),$sformat(rd_trans_h.RDATA))
                                                        //  `uvm_info(get_full_name(),$sformatf("SLV_DRIVER K ANDER : RDATA = %p ",rd_trans_h.RDATA),UVM_DEBUG)

               `uvm_info("SLV_DRIVER NE INTER_FACE PR BHEJA  RDATA_DEBUG",rd_trans_h.sprint,UVM_LOW)
           // slv_intf.axi_slv_drv_cb.RLAST  <= 1'b0;
            end
          end //forever
    endtask

           /*
           fork
              begin
                if(rd_data_q.size() == 0)begin
                slv_intf.axi_slv_drv_cb.RVALID <= 1'b0;
                end
              end
            join_none
              //seq_item_port.put_response(req);
           end
      endtask
      */


endclass
`endif


/*
     task resp_write();

       axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) wr_trans_resp;
     `uvm_info(get_full_name(),"SLAVE DRIVER WRITE RESPONSE STARTED",UVM_MEDIUM) //yes 2 

     forever begin
       wr_trans_resp = new();//TEMPORARILY CREATED FOR NOW
      //   if(wr_trans_resp == null)
      //   `uvm_fatal("NULL","wr_trans_resp is NULL");
     // `uvm_create(wr_trans_resp)  // yha nhi
      
          @(slv_intf.axi_slv_drv_cb);
          //slv_intf.axi_slv_drv_cb.BID <= wr_trans_resp.BID;    
          //slv_intf.axi_slv_drv_cb.BID <= req.BID;
          slv_intf.axi_slv_drv_cb.BID <= wr_trans_resp.BID;
          //slv_intf.axi_slv_drv_cb.BRESP <= req.BRESP;    
          slv_intf.axi_slv_drv_cb.BRESP <= wr_trans_resp.BRESP;    
          slv_intf.axi_slv_drv_cb.BVALID <= 1'b1;

          @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.BREADY);
         // slv_intf.axi_slv_drv_cb.BVALID <= 1'b0;
     end

     `uvm_info(get_full_name(),"SLAVE DRIVER WRITE RESPONSE STARTED",UVM_DEBUG)
      

     endtask
     */

//------------------------------read_address_channel--------------------------     
/*
     task rd_addr();
       forever begin

       @(slv_intf.axi_slv_drv_cb iff slv_intf.axi_slv_drv_cb.rvalid);
        slv_intf.axi_slv_drv_cb.arready <= 1'b1;
        
       end
     endtask
     */

