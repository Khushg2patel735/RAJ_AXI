
`ifndef AXI_SLV_AGENT_CONFIG
`define AXI_SLV_AGENT_CONFIG

class axi_slv_agent_config extends uvm_object;
  
  `uvm_object_utils(axi_slv_agent_config) 
  
  // Configuring active passive of slave agent;
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  
  // Handle of slave interface.
  virtual axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH) slv_intf;
  
  extern function new (string name = "axi_slv_agent_config");
  
endclass
    
    
function axi_slv_agent_config::new (string name = "axi_slv_agent_config");
    super.new(name);
endfunction
    

`endif
