/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date      : 11/09-2026
// Last Modifiey    :
// File Name   	    : axi_slv_mon.sv
// Class Name 	    : 
// Project Name	    : 
// Description	    : 
//////////////////////////////////////////////////////////////////////////


`ifndef AXI_SLV_MON_SV
`define AXI_SLV_MON_SV

class axi_slv_mon #(ADDR_WIDTH, DATA_WIDTH) extends uvm_monitor;

  `uvm_component_param_utils(axi_slv_mon #(ADDR_WIDTH, DATA_WIDTH))

  virtual axi_slv_intf #(ADDR_WIDTH, DATA_WIDTH) slv_intf;

  axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) aw_fifo[$];

  bit [DATA_WIDTH-1:0] slv_memory [bit [ADDR_WIDTH-1:0]];
  
  uvm_analysis_port #(axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)) slv_ana_port;

  function new(string name = "axi_slv_mon", uvm_component parent);
    super.new(name, parent);
    slv_ana_port = new("slv_ana_port", this);
  endfunction

  function void build_phase(uvm_phase phase);
                                 `uvm_info(get_full_name(), "AXI_SLV_MON build_phase STARTED", UVM_DEBUG)
    super.build_phase(phase);

    if (!uvm_config_db#(virtual axi_slv_intf #(ADDR_WIDTH, DATA_WIDTH))::get(this, "*", "slv_intf", slv_intf)) begin
       `uvm_fatal("SLV_MONITOR", "SLAVE VIRTUAL INTERFACE IS NOT FOUND")
    end
                                 `uvm_info(get_full_name(), "AXI_SLV_MON build_phase ENDED", UVM_DEBUG)
  endfunction

  task run_phase(uvm_phase phase);

    fork
      write_addr_sample();
      write_data_sample();
      rd_adder_sample();
    join
  endtask

    //--------------------------------------------------------------
  task write_addr_sample();
                   `uvm_info(get_full_name(), "AXI_SLV_MON_WRITE CHANNELS STARTED", UVM_DEBUG)    // YES
    forever begin
      @(slv_intf.axi_slv_mon_cb);
    // AW phase  : push entire  sequence_item  into the  fifo
      if (slv_intf.axi_slv_mon_cb.AWVALID && slv_intf.axi_slv_mon_cb.AWREADY) begin
        axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) aw_item;

       // `uvm_info(get_full_name(),$sformatf(" INSIDE MONITOR : AWVALID = %0d AWREADY =%0d",slv_intf.axi_slv_mon_cb.AWVALID,slv_intf.axi_slv_mon_cb.AWREADY),UVM_DEBUG)
        aw_item = axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("aw_item");

        //assign aw_item.trans_type == SLV_WRITE;
         aw_item.trans_type = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_WRITE;
      // aw_item.trans_type
        aw_item.AWID    = slv_intf.axi_slv_mon_cb.AWID;
        aw_item.AWADDR  = slv_intf.axi_slv_mon_cb.AWADDR;
        aw_item.AWLEN   = slv_intf.axi_slv_mon_cb.AWLEN;
        aw_item.AWSIZE  = slv_intf.axi_slv_mon_cb.AWSIZE;
        aw_item.AWBURST = slv_intf.axi_slv_mon_cb.AWBURST;

       // aw_item.SLV_WRITE = 1;
        `uvm_info(get_full_name(), $sformatf("*********SLV MON: AWID=%0d ADDR=%0h LEN=%0d SIZE = %0d BURST = %0d",aw_item.AWID, aw_item.AWADDR,aw_item.AWLEN,aw_item.AWSIZE,aw_item.AWBURST),UVM_DEBUG)

      // `uvm_info(get_full_name(),aw_item.sprint(),UVM_NONE) // yha tak aa rha h 
      `uvm_info("MONITOR BID_DEBUG ADDRESS_PHASE",aw_item.sprint(),UVM_NONE)
        
        aw_fifo.push_back(aw_item);
        
       // slv_ana_port.write(aw_item); //=============1st time put liya 
        
      end
    end
  endtask :write_addr_sample

  task write_data_sample();
    axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) current_wdata;
    axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) aw_item;
    bit [ADDR_WIDTH-1 :0]cur_addr;
    int beat_cnt = 0;
                                                       // `uvm_info(get_full_name(),"AXI_SLV_MON_WRITE_ADDRESS_CHANNEL STARTED ",UVM_DEBUG)    // YES
     forever begin

      @(slv_intf.axi_slv_mon_cb);// eske bina forever me chala jayega 
     
     if(slv_intf.axi_slv_mon_cb.WVALID && slv_intf.axi_slv_mon_cb.WREADY)begin 
          wait(aw_fifo.size() > 0);
                                                        // At the start of a burst, pull the AW item from the FIFO
                                                                    //if(beat_cnt == 0)begin
              current_wdata = aw_fifo.pop_front();
              cur_addr      = current_wdata.AWADDR;
                                                                                            // end
                                                                            // Store into monitor internal dynamic memory
          slv_memory[cur_addr]  = slv_intf.axi_slv_mon_cb.WDATA;

                                                                            // Create a NEW transaction object for THIS specific beat
          $cast(aw_item,current_wdata.clone());
                                                                            // `uvm_info(get_full_name(),aw_item.sprint(),UVM_NONE) // A wala data aa rha h 

                                                                            // Assign Beat-Specific Signals
        aw_item.WDATA = slv_intf.axi_slv_mon_cb.WDATA;
        aw_item.WSTRB = slv_intf.axi_slv_mon_cb.WSTRB;
        aw_item.WLAST = slv_intf.axi_slv_mon_cb.WLAST;
                                                                                // `uvm_info(get_full_name(),aw_item.sprint(),UVM_NONE)
      `uvm_info("MONITOR BID_DEBUG DATA_PHASE COLLECT SEQS",aw_item.sprint(),UVM_NONE)
                                                                                                        //slv_ana_port.write(aw_item);

                                                                                     // Address calculation logic for INCR burst (Word-aligned increment)
                                                                                         // if (current_wdata.AWBURST == 2'b01) begin // INCR type
                                                                                                     //   cur_addr = cur_addr + (1 << current_wdata.AWSIZE);
                                                                                                        //  end
                                                                                                    // slv_ana_port.write(aw_item);
                                                                                // Reset beat count on actual WLAST signal or when expected burst length is reached
                                                             // if (slv_intf.axi_slv_mon_cb.WLAST)begin //          end|| (beat_cnt == current_wdata.AWLEN)) begin
      @(slv_intf.axi_slv_mon_cb);// eske bina forever me chala jayega 
        wait(slv_intf.axi_slv_mon_cb.WLAST)
        //if(slv_intf.axi_slv_mon_cb.WLAST)                                           //@(slv_intf.axi_slv_mon_cb);// eske bina forever me chala jayega 
        slv_ana_port.write(aw_item);  ////=============2nd time put liya 
      `uvm_info("MONITOR BID_DEBUG DATA_PHASE SEND SEQS",aw_item.sprint(),UVM_NONE)
        //end
      end
     end
  endtask :write_data_sample


  task rd_adder_sample();
    forever begin 
      @(slv_intf.axi_slv_mon_cb);
      if(slv_intf.axi_slv_mon_cb.ARVALID && slv_intf.axi_slv_mon_cb.ARREADY)begin
         axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH) ar_item;
                                     //@(slv_intf.axi_slv_mon_cb iff slv_intf.axi_slv_mon_cb.ARVALID && slv_intf.axi_slv_mon_cb.ARREADY);
         
        ar_item = axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("ar_item");
      //  `uvm_info("ARID_DEBUG",ar_item.sprint,UVM_DEBUG) yha pr kuchh mil nhi rha 
       // ar_item.trans_type = SLV_READ;
         ar_item.trans_type = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_READ;
       // ar_item.ARID    = slv_intf.axi_slv_mon_cb.ARID;
        ar_item.ARID = slv_intf.axi_slv_mon_cb.ARID;

`uvm_info("ARID_CAPTURE",$sformatf("MONITOR CAPTURED ARID=%0h ARVALID=%0b ARREADY=%0b",ar_item.ARID,slv_intf.axi_slv_mon_cb.ARVALID,slv_intf.axi_slv_mon_cb.ARREADY),UVM_MEDIUM)
        
         // `uvm_info("ARID_DEBUG",$sformatf("SLV_MONITOR_K_ANDER_interface pr  ARID_DEBUG = %0h ",slv_intf.axi_slv_mon_cb.ARID),UVM_DEBUG)

        ar_item.ARADDR  = slv_intf.axi_slv_mon_cb.ARADDR;
        ar_item.ARLEN   = slv_intf.axi_slv_mon_cb.ARLEN;
        ar_item.ARSIZE  = slv_intf.axi_slv_mon_cb.ARSIZE;
        ar_item.ARBURST = slv_intf.axi_slv_mon_cb.ARBURST;
        
        //`uvm_info("ARID_DEBUG",ar_item.sprint,UVM_DEBUG)
        
          //`uvm_info("RID_DEBUG",$sformatf("SLV_MONITOR_K_ANDER PACKET_ME ARID_DEBUG = %0h | ARLEN = %0d",ar_item.ARID,ar_item.ARLEN),UVM_DEBUG)

        `uvm_info("ARID_DEBUG",ar_item.sprint,UVM_MEDIUM)
        slv_ana_port.write(ar_item);   //=============3rd time put liya 
      end
   //   @(slv_intf.axi_slv_mon_cb);
    end
  endtask :rd_adder_sample

  task rd_data_sample();

    forever begin 


    end
  endtask

endclass
`endif

