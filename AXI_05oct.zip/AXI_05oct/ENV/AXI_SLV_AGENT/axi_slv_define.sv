

`define ADDR_WIDTH 32
`define DATA_WIDTH 32
`define DEPTH 128
`define ID_SIZE 4
`define LENGTH 4
