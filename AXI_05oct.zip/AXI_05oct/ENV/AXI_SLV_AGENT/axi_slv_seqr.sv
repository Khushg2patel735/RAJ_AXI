/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date      : 10-07-2026
// Last Modifiey  : 
// File Name   	  : axi_slv_seqr.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
/////////////////////////////////////////////////////////////////////////


`ifndef AXI_SLV_SEQR_SV
`define AXI_SLV_SEQR_SV

class axi_slv_seqr #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_sequencer #(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH));

    `uvm_component_param_utils(axi_slv_seqr #(ADDR_WIDTH,DATA_WIDTH))

    //seq_item_export #(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH))  slv_ana_export;
    uvm_tlm_analysis_fifo #(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH)) write_mon_fifo;

    uvm_tlm_analysis_fifo #(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH)) read_mon_fifo;

    

    function new(string name = "axi_slv_seqr",uvm_component parent);
        super.new(name,parent);
       // slv_ana_export = new("slv_ana_export",this);
        write_mon_fifo  = new("write_mon_fifo",this);
        read_mon_fifo  = new("read_mon_fifo",this);
    endfunction

// a wala kaam mai agent k connect_phase me kr rha hu 

/*
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
        slv_ana_export.connect(req_item_fifo.analysis_export);
    endfunction
*/
endclass
`endif


