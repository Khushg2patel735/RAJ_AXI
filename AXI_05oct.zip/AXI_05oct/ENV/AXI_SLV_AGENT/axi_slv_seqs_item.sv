
/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : axi_slv_seqs_item.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////

class axi_slv_seqs_item #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_sequence_item;

  typedef enum  {
    SLV_WRITE,
    SLV_READ
  } slv_trans_type_e;

  rand  slv_trans_type_e trans_type ;
        
  // WRITE ADDRESS
  rand bit [`ID_SIZE-1:0] AWID;
  rand bit [ADDR_WIDTH-1:0] AWADDR;
  rand bit [`LENGTH-1:0] AWLEN;
  rand bit [2:0] AWSIZE;
  bit AWVALID;
  rand bit [1:0] AWBURST;

  // WRITE DATA
  rand bit [`ID_SIZE-1:0] WID;
  rand bit [DATA_WIDTH-1:0] WDATA;
  rand bit [DATA_WIDTH/8-1:0] WSTRB;
  rand bit WLAST;
  bit WVALID;
  bit WREADY;

  // WRITE RESPONSE
  bit BREADY;
  rand bit [`ID_SIZE-1:0] BID;
  bit [1:0] BRESP;
  bit BVALID;

  // READ ADDRESS
  randc bit [`ID_SIZE-1:0] ARID;
  rand bit [ADDR_WIDTH-1:0] ARADDR;
  randc bit [`LENGTH-1:0] ARLEN;
  rand bit [2:0] ARSIZE;
  rand bit [1:0] ARBURST;
  bit ARVALID;
  bit ARREADY;

  // READ DATA
   bit [`ID_SIZE-1:0] RID;
 // rand bit [DATA_WIDTH-1:0] RDATA;
  rand bit [DATA_WIDTH-1:0] RDATA[];
  bit [1:0] RRESP;
  bit RLAST;
  bit RREADY;
  bit RVALID;

 // constraint on_rlen {ARLEN == 4'h3; ARSIZE == 2;}
  //constraint on_bid{WID == BID;}

 // constraint on_id {RID == ARID;}

    constraint on_wdata_size {soft RDATA.size == ARLEN +1'b1;}
  

  function new(string name = "axi_slv_seqs_item");
    super.new(name);
  endfunction

  `uvm_object_param_utils_begin(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH))

    `uvm_field_enum(slv_trans_type_e,trans_type, UVM_ALL_ON)

    `uvm_field_int(AWID,   UVM_ALL_ON)
    `uvm_field_int(AWADDR,   UVM_ALL_ON)
    `uvm_field_int(AWLEN,   UVM_ALL_ON)
    `uvm_field_int(AWSIZE,   UVM_ALL_ON)
    `uvm_field_int(AWVALID,   UVM_ALL_ON)
    `uvm_field_int(AWBURST,   UVM_ALL_ON)


    `uvm_field_int(WID,   UVM_ALL_ON)
    `uvm_field_int(WDATA,   UVM_ALL_ON)
    `uvm_field_int(WSTRB,   UVM_ALL_ON)
    `uvm_field_int(WDATA,   UVM_ALL_ON)
    `uvm_field_int(WLAST,   UVM_ALL_ON)
    `uvm_field_int(WVALID,   UVM_ALL_ON)
    `uvm_field_int(WREADY,   UVM_ALL_ON)


    `uvm_field_int(BREADY, UVM_ALL_ON)
    `uvm_field_int(BID, UVM_ALL_ON)
    `uvm_field_int(BVALID, UVM_ALL_ON)
    `uvm_field_int(BRESP, UVM_ALL_ON)

    `uvm_field_int(ARID,   UVM_ALL_ON)
    `uvm_field_int(ARADDR,   UVM_ALL_ON)
    `uvm_field_int(ARLEN,   UVM_ALL_ON)
    `uvm_field_int(ARSIZE,   UVM_ALL_ON)
    `uvm_field_int(ARBURST,   UVM_ALL_ON)
    `uvm_field_int(ARVALID,   UVM_ALL_ON)
    `uvm_field_int(ARREADY,   UVM_ALL_ON)


    `uvm_field_int(WDATA,   UVM_ALL_ON)
    `uvm_field_int(WDATA,   UVM_ALL_ON)

    `uvm_field_int(RID,   UVM_ALL_ON)
    `uvm_field_array_int(RDATA, UVM_ALL_ON)
   // `uvm_field_int(RDATA, UVM_ALL_ON)
    `uvm_field_int(RRESP, UVM_ALL_ON)
    `uvm_field_int(RLAST, UVM_ALL_ON)
    `uvm_field_int(RVALID, UVM_ALL_ON)
    `uvm_field_int(RREADY, UVM_ALL_ON)

  `uvm_object_utils_end

endclass












/*
`ifndef AXI_SLV_SEQS_ITEM_SV
`define AXI_SLV_SEQS_ITEM_SV

`include "axi_mas_define.sv"

class axi_slv_seqs_item #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_sequence_item;

   //-------write address channel----------//
       //  bit AWREADY;
    rand bit  [`ID_SIZE-1 :0] AWID;
    rand bit  [ADDR_WIDTH-1 :0] AWADDR;
    rand bit  [`LENGTH-1 :0] AWLEN;
    rand bit  [2:0]AWSIZE;
         bit   AWVALID;
    rand bit  [1:0]AWBURST;
    
    //------write data channel-----------//
    rand bit [`ID_SIZE-1 :0] WID;
    rand bit [DATA_WIDTH-1 :0] WDATA;
    rand bit [DATA_WIDTH/8-1 :0] WSTRB;
    rand bit  WLAST;
         bit  WVALID;    
         bit  WREADY;

   //------write response channel-------//
         bit BREADY;
    rand bit [`ID_SIZE-1 :0] BID;
         bit [1:0] BRESP;
         bit BVALID;

   //------read address channel signal---//
    rand bit [`ID_SIZE-1 :0] ARID;
    rand bit [ADDR_WIDTH-1 :0] ARADDR;
    rand bit [`LENGTH-1 :0] ARLEN;
    rand bit [2:0] ARSIZE;
    rand bit [1:0] ARBURST;
         bit  ARVALID;
         bit ARREADY;
        

   //-------read data channel signal-----//

    rand bit [`ID_SIZE-1 :0] RID;
    rand bit [DATA_WIDTH-1 :0] RDATA;
         bit [1 :0] RRESP;         
         bit RLAST;
         bit RREADY;
         bit RVALID;
    

    //constraint on_rdata{soft RDATA.size() ==ARLEN+1'b1; ARSIZE ==2;}
    constraint on_rlen{ARLEN == 4'h3;}
    constraint on_id{RID == ARID;}

    function new(string name = "axi_slv_seqs_item");
      super.new(name);
    endfunction

    `uvm_object_param_utils_begin(axi_slv_seqs_item #(ADDR_WIDTH,DATA_WIDTH))


    `uvm_field_int(BID,     UVM_ALL_ON)
    `uvm_field_int(BRESP,   UVM_ALL_ON)

    `uvm_field_int(RID,     UVM_ALL_ON)
    `uvm_field_int(RDATA,   UVM_ALL_ON)
    `uvm_field_int(RRESP,   UVM_ALL_ON)
    `uvm_field_int(RLAST,   UVM_ALL_ON)

    `uvm_object_utils_end


endclass
`endif

*/
