/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 20-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_param_slv_agent.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////



`ifndef AXI_SLV_AGENT_SV
`define AXI_SLV_AGENT_SV

class axi_slv_agent #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_agent;
    
  `uvm_component_param_utils(axi_slv_agent #(ADDR_WIDTH,DATA_WIDTH))
 
  //  function new(string name = "axi_slv_agent",uvm_component parent);
    //  super.new(name,parent);

   // endfunction

    
   axi_slv_drv #(ADDR_WIDTH,DATA_WIDTH)  slv_drv_h;
   axi_slv_mon #(ADDR_WIDTH,DATA_WIDTH)  slv_mon_h;
   axi_slv_seqr #(ADDR_WIDTH,DATA_WIDTH) slv_seqr_h;

   axi_slv_agent_config axi_s_agent_config;

    extern function new(string name = "axi_slv_agent",uvm_component parent);

    extern function void build_phase(uvm_phase phase);

    extern function void connect_phase(uvm_phase phase);
    
endclass

function axi_slv_agent::new(string name = "axi_slv_agent",uvm_component parent);
    super.new(name,parent);
endfunction


function void axi_slv_agent::build_phase(uvm_phase phase);
    super.build_phase(phase); 
    `uvm_info(get_full_name(),"AXI_SLAVE_AGENT BULID_PHASE STARTED",UVM_DEBUG);
      if(axi_s_agent_config.is_active == UVM_ACTIVE)
        begin
        slv_drv_h = axi_slv_drv #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("slv_drv_h",this);

        //assign interface
        slv_drv_h.slv_intf = axi_s_agent_config.slv_intf;
        slv_seqr_h = axi_slv_seqr #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("slv_seqr_h",this);
        end

        slv_mon_h = axi_slv_mon #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("slv_mon_h",this);
        slv_mon_h.slv_intf = axi_s_agent_config.slv_intf;
      
     `uvm_info(get_full_name(),"AXI_MASTER_AGENT BULID_PHASE ENDED",UVM_DEBUG);
endfunction


function void axi_slv_agent::connect_phase(uvm_phase phase);
    super.connect_phase(phase);

  `uvm_info(get_full_name(),"AXI_SLV_AGENT connect_phase STARTED",UVM_DEBUG)

  if (axi_s_agent_config.is_active == UVM_ACTIVE) begin
    // Sequencer -> Driver
      //slv_seqr_h.seq_item_export.connect(slv_drv_h.seq_item_port);//export to port wrong connection 
      slv_drv_h.seq_item_port.connect(slv_seqr_h.seq_item_export);
    // Monitor -> Reactive FIFO
   // slv_mon_h.slv_ana_port.connect(slv_seqr_h.mon_fifo.analysis_export);
    slv_mon_h.slv_ana_port.connect(slv_seqr_h.write_mon_fifo.analysis_export);
    //slv_mon_h.slv_ana_port.connect(slv_seqr_h.read_mon_fifo.analysis_export);
    slv_mon_h.slv_ana_port.connect(slv_seqr_h.read_mon_fifo.analysis_export);
  end

  `uvm_info(get_full_name(),"AXI_SLV_AGENT connect_phase ENDED",UVM_DEBUG)

endfunction

`endif
