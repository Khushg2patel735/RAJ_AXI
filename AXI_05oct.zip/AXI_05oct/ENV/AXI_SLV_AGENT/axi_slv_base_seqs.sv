`ifndef AXI_SLV_BASE_SEQS_SV
`define AXI_SLV_BASE_SEQS_SV

class axi_slv_base_seqs #(parameter ADDR_WIDTH = 32,parameter DATA_WIDTH = 32) extends uvm_sequence #(axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH));

    `uvm_object_param_utils(axi_slv_base_seqs #(ADDR_WIDTH, DATA_WIDTH))

    `uvm_declare_p_sequencer(axi_slv_seqr #(ADDR_WIDTH, DATA_WIDTH))

  //========================================================
  // Slave Memory
  //========================================================
  bit [DATA_WIDTH-1:0] slv_mem [bit [ADDR_WIDTH-1:0]];
  //========================================================
  // Constructor
  //========================================================

  function new(string name = "axi_slv_base_seqs");
    super.new(name);
  endfunction

 //========================================================
  // BODY
  //========================================================
   task body();
                                               `uvm_info(get_full_name(), "============ SLV SEQS BODY STARTED ============", UVM_DEBUG)
   fork
      writes();
      reads();
   join
                                               `uvm_info(get_full_name(), "============ SLV SEQS BODY ENDED ============", UVM_DEBUG)
  endtask


  //========================================================
  // Memory WRITE
  //========================================================
  task writes();
    axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) write_item;
    axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) write_rsp;

    forever begin
                                                                             // Fetch write transaction from the write monitor FIFO
      p_sequencer.write_mon_fifo.get(write_item);
                                                                            `uvm_info("SEQUECE BID_DEBUG RECEIVE",write_item.sprint(),UVM_DEBUG)
      if (write_item.trans_type == axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_WRITE) begin
        // Update local memory
        slv_mem[write_item.AWADDR] = write_item.WDATA;

        // Create Write Response item (B channel)
        write_rsp = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::type_id::create("write_rsp");
        
        write_rsp.trans_type = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_WRITE;
        write_rsp.BID   = write_item.AWID;
                                                                    `uvm_info(get_full_name(),$sformatf("AFTER WRITE_TRANSE  = %0d",write_rsp.BID),UVM_DEBUG)//  ok
        write_rsp.BRESP = 2'b00; // OKAY response
                                                                    `uvm_info("SEQUECE BID_DEBUG SEND",write_rsp.sprint(),UVM_DEBUG)
        start_item(write_rsp);
       // finish_item();
        finish_item(write_rsp);
      end
    end
  endtask

  //========================================================
  // Memory READ
  //========================================================  //------------------------------------------------------------------
  task reads();

  axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) read_item;
  axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH) read_rsp;
  bit [ADDR_WIDTH-1:0] current_addr;

  forever begin
    // Get READ request from monitor
    p_sequencer.read_mon_fifo.get(read_item);
                                   `uvm_info("ARID_DEBUG",read_item.sprint(),UVM_DEBUG)
    // Create READ response

      if (read_item.trans_type == axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::SLV_READ) begin
    
       read_rsp = axi_slv_seqs_item #(ADDR_WIDTH, DATA_WIDTH)::type_id::create("read_rsp");

    end
                                     `uvm_info("ARID_DEBUG",$sformatf("ARID_DEBUG=%0h", read_item.ARID),UVM_DEBUG)
    // Response fields
   // read_rsp.ARID  = read_item.ARID;
    read_rsp.RID   = read_item.ARID;
    read_rsp.ARLEN = read_item.ARLEN;
  /*
    foreach(read_item.RDATA[i])begin
     read_rsp.RDATA[i] = read_item.RDATA[i];
    read_rsp.RLAST = 1'b1;
   // read_rsp.RLAST = read_item.ARLEN;//SAME RLAST AA RHA PR ARLEN k according data nhi aa rha h 
   end
  */
    read_rsp.RRESP = 2'b00;
    //read_rsp.RLAST = 1'b1;
                                       `uvm_info("ARID_DEBUG",read_rsp.sprint,UVM_MEDIUM)
    // Send response to slave driver
    start_item(read_rsp);
    finish_item(read_rsp);
   end
  endtask

endclass
`endif



