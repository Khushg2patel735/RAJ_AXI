	/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 24-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_slv_intf.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
/////////////////////////////////////////////////////////////////////////

`ifndef AXI_SLV_INTF_SV
`define AXI_SLV_INTF_SV

`include "axi_slv_define.sv"

interface axi_slv_intf #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32)(input logic ACLK,input logic ARESETn);

   // logic ARESETn;
    //logic ACLK;

   //-------write address channel----------//
    logic [`ID_SIZE-1 :0] AWID;
    logic [ADDR_WIDTH-1 :0] AWADDR;
    logic [`LENGTH-1 :0] AWLEN;
    logic [2:0]AWSIZE;
    logic  AWVALID;
    logic [1:0]AWBURST;
    
    logic  AWREADY;
   // logic  AWREADY = 1'b1;

    //------write data channel-----------//
    logic [`ID_SIZE-1 :0] WID;
    logic [DATA_WIDTH-1 :0] WDATA;
    logic [DATA_WIDTH/8-1 :0] WSTRB;
    logic WLAST;
    logic WVALID;  
    logic  WREADY;
    //logic  WREADY = 1;

   //------write response channel-------//
    logic BREADY;
    logic  [`ID_SIZE-1 :0] BID;
    logic  [1:0] BRESP;
    logic  BVALID;

   //------read address channel signal---//
    logic [`ID_SIZE-1 :0] ARID;
    logic [ADDR_WIDTH-1 :0] ARADDR;
    logic [`LENGTH-1 :0] ARLEN;
    logic [2:0] ARSIZE;
    logic [1:0] ARBURST;
    logic ARVALID;
    logic ARREADY;


   //-------read data channel signal-----//
    logic RREADY;

    logic  [`ID_SIZE-1 :0] RID;
    logic  [DATA_WIDTH-1 :0] RDATA;
    logic  [1 :0] RRESP;
    logic  RLAST;
    logic  RVALID;

    // .............AXI SLV_DRIVER CLOCKING BLOCK ..............
    
    clocking axi_slv_drv_cb @(posedge ACLK);
     default input #1 output #0;

  //================ Write Address Channel ================

  input  AWID;
  input  AWADDR;
  input  AWLEN;
  input  AWSIZE;
  input  AWVALID;

  output AWREADY;

  //================ Write Data Channel ===================

  input  WID;
  input  WDATA;
  input  WSTRB;
  input  WLAST;
  input  WVALID;

  output WREADY;

  //================ Write Response Channel ===============

  input  BREADY;

  output BID;
  output BRESP;
  output BVALID;

  //================ Read Address Channel =================

  input  ARID;
  input  ARADDR;
  input  ARLEN;
  input  ARSIZE;
  input  ARBURST;
  input  ARVALID;

  output ARREADY;

  //================ Read Data Channel ====================

  input  RREADY;

  output RID;
  output RDATA;
  output RRESP;
  output RLAST;
  output RVALID;

endclocking

    clocking axi_slv_mon_cb @(posedge ACLK);
      default input #1 output #0;

  input AWID;
  input AWADDR;
  input AWLEN;
  input AWSIZE;
  input AWVALID;
  input AWREADY;
  input AWBURST;

  input WID;
  input WDATA;
  input WSTRB;
  input WLAST;
  input WVALID;
  input WREADY;

  input BREADY;
  input BID;
  input BRESP;
  input BVALID;

  input ARID;
  input ARADDR;
  input ARLEN;
  input ARSIZE;
  input ARBURST;
  input ARVALID;
  input ARREADY;

  input RREADY;
  input RID;
  input RDATA;
  input RRESP;
  input RLAST;
  input RVALID;

endclocking

endinterface
`endif

