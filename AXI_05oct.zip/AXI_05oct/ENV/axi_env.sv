/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 25-07-2026
// Last Modifiey  : 
// File Name   	  : axi_env.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////


`ifndef AXI_ENV_SV
`define AXI_ENV_SV

class axi_env extends uvm_env;

    `uvm_component_utils(axi_env)
  
  // AXI ENV CONFIG
  axi_env_config axi_env_cfg;
  
  //MASTER AGENT
  axi_mas_agent #(`ADDR_WIDTH,`DATA_WIDTH)  mas_agent_h[];
  
  //SLAVE AGENT
  axi_slv_agent #(`ADDR_WIDTH,`DATA_WIDTH)  slv_agent_h[];

  
    function new(string name = "axi_env",uvm_component parent);
      super.new(name,parent);
    endfunction 

    function void build_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_SLV_ENV build_phase STARTED",UVM_DEBUG);
      super.build_phase(phase);

      if(!uvm_config_db #(axi_env_config)::get(this,"*","AXI_ENV_CONFIG",axi_env_cfg))
        `uvm_fatal("env_config","Not getting anv config info in env");
      //create number of master agent
      if(axi_env_cfg.has_mas_agent)begin
        mas_agent_h = new[axi_env_cfg.no_of_mas_agent];
        foreach(mas_agent_h[i])begin
          mas_agent_h[i] = axi_mas_agent#(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create($sformatf("axi_mas_agent[%0d]",i),this);
          mas_agent_h[i].axi_m_agent_config = axi_env_cfg.axi_m_agent_config[i];
          mas_agent_h[i].axi_m_agent_config.mas_intf = axi_env_cfg.axi_m_agent_config[i].mas_intf;
        end
      end

      if(axi_env_cfg.has_slv_agent)begin
        slv_agent_h = new[axi_env_cfg.no_of_slv_agent];
        foreach(slv_agent_h[i])begin
          slv_agent_h[i] = axi_slv_agent#(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create($sformatf("axi_slv_agent[%0d]",i),this);
          slv_agent_h[i].axi_s_agent_config = axi_env_cfg.axi_s_agent_config[i];
          slv_agent_h[i].axi_s_agent_config.slv_intf = axi_env_cfg.axi_s_agent_config[i].slv_intf;
        end
      end
    //  mas_agent_h = axi_mas_agent #(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create("mas_agent_h",this);
    //  slv_agent_h = axi_slv_agent #(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create("slv_agent_h",this);
      `uvm_info(get_full_name(),"AXI_SLV_ENV build_phase ENDED",UVM_DEBUG);
    endfunction

    function void connect_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_SLV_ENV connect_phase STARTED",UVM_DEBUG);

    endfunction
endclass
`endif








/*

`ifndef AXI_ENV_SV
`define AXI_ENV_SV

class axi_env extends uvm_env;

    `uvm_component_param_utils(axi_env)

    axi_mas_agent #(`ADDR_WIDTH,`DATA_WIDTH)  mas_agent_h;
    axi_slv_agent #(`ADDR_WIDTH,`DATA_WIDTH)  slv_agent_h;



    function new(string name = "axi_env",uvm_component parent);
      super.new(name,parent);

    endfunction 

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mas_agent_h = axi_mas_agent #(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create("mas_agent_h",this);
        slv_agent_h = axi_slv_agent #(`ADDR_WIDTH,`DATA_WIDTH)::type_id::create("slv_agent_h",this);

    endfunction

    function void connect_phase(uvm_phase phase);
      
        
    endfunction 



endclass



`endif
*/

