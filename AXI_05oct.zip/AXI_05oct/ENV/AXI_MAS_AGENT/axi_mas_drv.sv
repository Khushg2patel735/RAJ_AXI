/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_param_mas_drv.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////

`ifndef AXI_MAS_DRV_SV
`define AXI_MAS_DRV_SV

class axi_mas_drv #(parameter ADDR_WIDTH = 32, DATA_WIDTH = 32) 
        extends uvm_driver #(axi_mas_seqs_item #(ADDR_WIDTH, DATA_WIDTH),axi_mas_seqs_item #(ADDR_WIDTH, DATA_WIDTH));

  `uvm_component_param_utils(axi_mas_drv #(ADDR_WIDTH, DATA_WIDTH))

  virtual axi_mas_intf #(ADDR_WIDTH, DATA_WIDTH) mas_intf;

  // Queues per channel
  axi_mas_seqs_item #(32,32) wr_addr_q[$];
  axi_mas_seqs_item #(32,32) wr_data_q[$];
  axi_mas_seqs_item #(32,32) rd_addr_q[$];

  bit pipe_line_drv = 1;
  event wr_done_ev;
  event rd_done_ev;

  function new(string name = "axi_mas_drv", uvm_component parent);
    super.new(name, parent);
  endfunction

  //--------------------------RUN_PHASE----------------------------------------------------
  task run_phase(uvm_phase phase);
                                          `uvm_info(get_full_name(), "AXI_MAS_DRV run_phase STARTED", UVM_MEDIUM);  //YES 1
    fork
    forever begin
      seq_item_port.get_next_item(req);
                                          `uvm_info(get_full_name(),"**********************GET_AND_DRIVER RUN PHASE STARTED*********",UVM_MEDIUM)  // YES 
     // if (req.trans_type == axi_mas_seqs_item#(ADDR_WIDTH, DATA_WIDTH)::MAS_WRITE) begin
                                          `uvm_info(get_full_name(),"********************MAS_WRITE SEQUENCE IN THE GET NEXT ITEM*************",UVM_MEDIUM)  // YES
        wr_addr_q.push_back(req);
        wr_data_q.push_back(req);
       // rd_addr_q.push_back(req);
                                          `uvm_info(get_full_name(),"*********************MAS_WRITE SEQUENCE IN THE GET NEXT ITEM*************",UVM_MEDIUM)  // YES
        if (!pipe_line_drv) @(wr_done_ev);//jab write done 
        rd_addr_q.push_back(req);
     // end
      //else begin

       // if (!pipe_line_drv) @(rd_done_ev); // Block sequence until full read burst finishes
     // end

                                          `uvm_info(get_full_name(),"****************MAS_WRITE SEQUENCE IN THE GET NEXT ITEM*************",UVM_MEDIUM)
      $cast(rsp, req.clone());
                                          `uvm_info(get_full_name(),"*****************MAS_WRITE SEQUENCE IN THE GET NEXT ITEM*************",UVM_MEDIUM)
      
      rsp.set_id_info(req);
                                          `uvm_info(get_full_name(),"*************MAS_WRITE SEQUENCE IN THE GET NEXT ITEM*************",UVM_MEDIUM)

                                          `uvm_info(get_full_name(),"MASTER_DRIVER BEFORE ITEM DONE",UVM_LOW)
      seq_item_port.item_done();
                                          `uvm_info(get_full_name(),"MASTER DRIVER AFTER ITEM DONE",UVM_LOW)
    end
    join_none

    fork
      wr_addr_channel();
      wr_data_channel();
      wr_resp_channel();
      rd_addr_channel();
      rd_data_channel();
    join
  endtask : run_phase

  //--------------------------WRITE_ADDRESS_CHANNEL---------------------------------------    
  task wr_addr_channel();
    axi_mas_seqs_item #(32,32) wr_trans;

    forever begin
      wait(wr_addr_q.size() != 0);
      wr_trans = wr_addr_q.pop_front();

    // @(mas_intf.axi_mas_drv_cb);
      mas_intf.axi_mas_drv_cb.AWID    <= wr_trans.AWID;
      mas_intf.axi_mas_drv_cb.AWADDR  <= wr_trans.AWADDR;
      mas_intf.axi_mas_drv_cb.AWLEN   <= wr_trans.AWLEN;
      mas_intf.axi_mas_drv_cb.AWSIZE  <= wr_trans.AWSIZE;
      mas_intf.axi_mas_drv_cb.AWBURST <= wr_trans.AWBURST;
      mas_intf.axi_mas_drv_cb.AWVALID <= 1'b1;

     // wr_trans_addr.print();
                                                 `uvm_info(get_full_name(),wr_trans.sprint,UVM_LOW)

    //  `uvm_info("MASTER_DRV",$sformatf( "WR_ADDR_CHANNEL : AWID=%0d AWADDR=%0d AWLEN = %0d AWSIZE = %0d AWBURST  = %0d",mas_intf.axi_mas_drv_cb.AWID,mas_intf.axi_mas_drv_cb.AWADDR,mas_intf.axi_mas_drv_cb.AWLEN,mas_intf.axi_mas_drv_cb.AWSIZE,mas_intf.axi_mas_drv_cb.AWBURST), UVM_MEDIUM)  // YES

      @(mas_intf.axi_mas_drv_cb iff mas_intf.axi_mas_drv_cb.AWREADY);
                                                 `uvm_info(get_full_name(),"AWREADY CALL ",UVM_MEDIUM)

      mas_intf.axi_mas_drv_cb.AWVALID <= 1'b0;
    end
  endtask

  //----------------------------------WRITE_DATA_CHANNEL---------------------------------    
  task wr_data_channel();
    axi_mas_seqs_item #(32,32) wr_trans_data;
    forever begin
      wait(wr_data_q.size() != 0);
      wr_trans_data = wr_data_q.pop_front();
      foreach(wr_trans_data.WDATA[i]) begin
       // @(mas_intf.axi_mas_drv_cb);
        mas_intf.axi_mas_drv_cb.WID    <= wr_trans_data.WID;
        mas_intf.axi_mas_drv_cb.WSTRB  <= wr_trans_data.WSTRB;
        mas_intf.axi_mas_drv_cb.WDATA  <= wr_trans_data.WDATA[i];
        mas_intf.axi_mas_drv_cb.WVALID <= 1'b1;
        mas_intf.axi_mas_drv_cb.WLAST  <= (i == wr_trans_data.AWLEN) ? 1:0;
                                        // `uvm_info("MASTER_DRV",$sformatf( "WDATA_CHANNEL : WID=%0d WSTRB=%0d WDATA = %0d",
                                             // mas_intf.axi_mas_drv_cb.WID,mas_intf.axi_mas_drv_cb.WSTRB,mas_intf.axi_mas_drv_cb.WDATA),UVM_MEDIUM)
      // wr_trans_Data.print();
       //@(mas_intf.axi_mas_drv_cb iff mas_intf.axi_mas_drv_cb.WLAST && mas_intf.axi_mas_drv_cb.WREADY);
       @(mas_intf.axi_mas_drv_cb iff mas_intf.axi_mas_drv_cb.WREADY);
                                           `uvm_info(get_full_name(),"=====WREAD====",UVM_MEDIUM)
     // end
      //@(mas_intf.axi_mas_drv_cb);
      mas_intf.axi_mas_drv_cb.WLAST  <= 1'b0;
      mas_intf.axi_mas_drv_cb.WVALID <= 1'b0;
      end
     ->wr_done_ev;
    end
  endtask

  //------------------------------------WRITE_RESPONSE_CHANNEL------------------------------
   
   task wr_resp_channel();
                                           `uvm_info(get_full_name(),"MAS DRIVER WRITE RESPONSE STARTED",UVM_MEDIUM)   // YES 2
                                       // mas_intf.axi_mas_drv_cb.BREADY <= 1'b1;
      forever begin
                                       // @(mas_intf.axi_mas_drv_cb iff  mas_intf.axi_mas_drv_cb.BVALID && mas_intf.axi_mas_drv_cb.BREADY);
       // @(mas_intf.axi_mas_drv_cb)// iff  mas_intf.axi_mas_drv_cb.BVALID);
       @(mas_intf.axi_mas_drv_cb iff mas_intf.axi_mas_drv_cb.BVALID);
        mas_intf.axi_mas_drv_cb.BREADY <= 1'b1;
        
       // `uvm_info(get_full_name(),mas_intf.axi_mas_drv_cb.sprint,UVM_NONE)
                                       // `uvm_info("MASTER_DRV",$sformatf("********B RESPONSE RECEIVED: BID=%0d BRESP=%0d**********",mas_intf.axi_mas_drv_cb.BID,mas_intf.axi_mas_drv_cb.BRESP), UVM_HIGH)//YES
      end

                                          `uvm_info(get_full_name(),"MAS DRIVER WRITE RESPONSE ENDED",UVM_MEDIUM)
    endtask


  //-----------------------------------READ_ADDRESS_CHANNEL---------------------------------

  task rd_addr_channel();
    axi_mas_seqs_item #(32,32) rd_trans_addr;

    forever begin 
      wait(rd_addr_q.size() != 0);
      rd_trans_addr = rd_addr_q.pop_front();

        `uvm_info("BEFORE ARID_DEBUG",rd_trans_addr.sprint,UVM_DEBUG)

      //    `uvm_info("MASTER_DRIVER_QUEUE_K ANDER",$sformatf("MASTER_DRIVER_QUEUE_K_ANDER ARID_DEBUG  ARID_DEBUG = %0d | ARLEN =%0d",rd_trans_addr.ARID,rd_trans_addr.ARLEN),UVM_DEBUG)

     // @(mas_intf.axi_mas_drv_cb);
      mas_intf.axi_mas_drv_cb.ARID    <= rd_trans_addr.ARID;
      mas_intf.axi_mas_drv_cb.ARADDR  <= rd_trans_addr.ARADDR;
      mas_intf.axi_mas_drv_cb.ARLEN   <= rd_trans_addr.ARLEN;
      mas_intf.axi_mas_drv_cb.ARSIZE  <= rd_trans_addr.ARSIZE;
      mas_intf.axi_mas_drv_cb.ARBURST <= rd_trans_addr.ARBURST;
      mas_intf.axi_mas_drv_cb.ARVALID <= 1'b1;

      @(mas_intf.axi_mas_drv_cb iff mas_intf.axi_mas_drv_cb.ARREADY);
     // @(mas_intf.axi_mas_drv_cb);
      mas_intf.axi_mas_drv_cb.ARVALID <= 1'b0;
      @(mas_intf.axi_mas_drv_cb);
        `uvm_info("AFTER ARID_DEBUG",rd_trans_addr.sprint,UVM_DEBUG)
                                                // Do NOT trigger rd_done_ev here! Wait for Read Data phase to finish.
    end
  endtask

  //----------------------------------READ_DATA_CHANNEL--------------------------------------
  task rd_data_channel();

                                             `uvm_info(get_full_name(),"BEFOR RD_DATA_CHANNEL STARTED",UVM_MEDIUM)
    forever begin
//      @(mas_intf.axi_mas_drv_cb);
    @(mas_intf.axi_mas_drv_cb iff mas_intf.axi_mas_drv_cb.RVALID);
        mas_intf.axi_mas_drv_cb.RREADY <= 1'b1;
     
         // ->rd_done_ev; // UNBLOCK get_and_drive() ONLY WHEN ENTIRE READ BURST FINISHES
    end
                                             `uvm_info(get_full_name(),"AFTER RD_DATA_CHANNEL ENDED",UVM_MEDIUM)
  endtask



endclass
`endif

