/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_param_mas_seqr.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
/////////////////////////////////////////////////////////////////////////


`ifndef AXI_MAS_SEQR_SV
`define AXI_MAS_SEQR_SV

class axi_mas_seqr #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_sequencer #(axi_mas_seqs_item #(ADDR_WIDTH,DATA_WIDTH));
    
    `uvm_component_param_utils(axi_mas_seqr #(ADDR_WIDTH,DATA_WIDTH))
    

    //uvm_analysis_export #(axi_mas_seqs_item #(ADDR_WIDTH,DATA_WIDTH))  seq_item_export;
    
    extern function new(string name = "axi_mas_seqr",uvm_component parent);

    extern function void build_phase(uvm_phase phase);

    extern function void connect_phase(uvm_phase phase);

    extern function void end_of_elaboration_phase(uvm_phase phase);

    extern function void start_of_simulation_phase(uvm_phase phase);

    extern task run_phase(uvm_phase phase);


endclass

function axi_mas_seqr::new(string name = "axi_mas_seqr",uvm_component parent);
    super.new(name,parent);
   // seq_item_export = new("seq_item_export",this);
endfunction

function void axi_mas_seqr::build_phase(uvm_phase phase);

    `uvm_info(get_full_name(),"AXI_MAS_SEQR_BUILD_PHASE STARTED",UVM_DEBUG);

    `uvm_info(get_full_name(),"AXI_MAS_SEQR_BUILD_PHASE ENDED",UVM_DEBUG);    
endfunction

function void axi_mas_seqr::connect_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_MAS_SEQR_CONNECT_PHASE STARTED",UVM_DEBUG);
    super.connect_phase(phase);

    `uvm_info(get_full_name(),"AXI_MAS_SEQR_CONNECT_PHASE ENDED",UVM_DEBUG);
endfunction

function void axi_mas_seqr::end_of_elaboration_phase(uvm_phase phase);

endfunction

function void axi_mas_seqr::start_of_simulation_phase(uvm_phase phase);

endfunction

task axi_mas_seqr::run_phase(uvm_phase phase);

    `uvm_info(get_full_name(),"AXI_MAS_SEQR_RUN_PHASE STARTED",UVM_DEBUG);
    
    `uvm_info(get_full_name(),"AXI_MAS_SEQR_RUN_PHASE ENDED",UVM_DEBUG);
endtask



`endif

