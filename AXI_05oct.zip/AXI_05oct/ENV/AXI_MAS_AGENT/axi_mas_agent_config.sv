
`ifndef AXI_MAS_AGENT_CONFIG
`define AXI_MAS_AGENT_CONFIG

class axi_mas_agent_config extends uvm_object;
  
  `uvm_object_utils(axi_mas_agent_config) 
  
  // Configuring active passive of master agent;
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  
  // Handle of master interface.
  virtual axi_mas_intf #(`ADDR_WIDTH,`DATA_WIDTH) mas_intf;
  
  function new (string name = "axi_mas_agent_config");
    super.new(name);
  endfunction
  
  
endclass
    
    
    //  function axi_mas_agent_config::new (string name = "axi_mas_agent_config");
    //     super.new(name);
    //  endfunction
    

`endif
