/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : axi_mas_agent.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////



`ifndef AXI_MAS_AGENT_SV
`define AXI_MAS_AGENT_SV

class axi_mas_agent #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_agent;
    
  `uvm_component_param_utils(axi_mas_agent #(ADDR_WIDTH,DATA_WIDTH))
//#(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32))

   axi_mas_drv #(ADDR_WIDTH,DATA_WIDTH)   mas_drv_h;
   axi_mas_mon #(ADDR_WIDTH,DATA_WIDTH)   mas_mon_h;
   axi_mas_seqr #(ADDR_WIDTH,DATA_WIDTH)  mas_seqr_h;

   axi_mas_agent_config axi_m_agent_config;

 
    function new(string name = "axi_mas_agent",uvm_component parent);
      super.new(name,parent);

    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      `uvm_info(get_full_name(),"AXI_MASTER_AGENT BULID_PHASE STARTED",UVM_DEBUG);

    if(axi_m_agent_config.is_active == UVM_ACTIVE)begin
      `uvm_info(get_full_name(),"----------MAS_AGENT_CONFIG IS ACTIVE------------",UVM_DEBUG);
      
      //create driver 
      mas_drv_h = axi_mas_drv #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("mas_drv_h",this);
      `uvm_info(get_full_name(),"MAS_DRV_AGENT_CREATED",UVM_DEBUG);
      //assign driver interface
      mas_drv_h.mas_intf = axi_m_agent_config.mas_intf;
      `uvm_info(get_full_name(),"MAS_DRV_ELSE_STATEMENT_AGENT_CREATED",UVM_DEBUG);
      
      mas_seqr_h = axi_mas_seqr #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("mas_seqr_h",this);
      `uvm_info(get_full_name(),"MAS_SEQR_AGENT_CREATED",UVM_DEBUG); 
    end

      mas_mon_h = axi_mas_mon #(ADDR_WIDTH,DATA_WIDTH)::type_id::create("mas_mon_h",this);
      `uvm_info(get_full_name(),"MAS_MON_AGENT_CREATED",UVM_DEBUG); 
      //assign monitor interface
      mas_mon_h.mas_intf = axi_m_agent_config.mas_intf;

      `uvm_info(get_full_name(),"AXI_MASTER_AGENT BULID_PHASE END",UVM_DEBUG);
    endfunction
    
    function void connect_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_MAS_AGENT build_phase started",UVM_DEBUG);
    super.connect_phase(phase);
    if(axi_m_agent_config.is_active == UVM_ACTIVE)begin
      mas_drv_h.seq_item_port.connect(mas_seqr_h.seq_item_export);
      end
    else
      mas_drv_h.seq_item_port.connect(mas_seqr_h.seq_item_export);
    `uvm_info(get_full_name(),"AXI_MAS_AGENT build_phase ENDED",UVM_DEBUG);

endfunction

   // extern function void connect_phase(uvm_phase phase);

    extern function void end_of_elaboration_phase(uvm_phase phase);

    extern function void start_of_simulation_phase(uvm_phase phase);

    extern task run_phase(uvm_phase phase);




endclass

/*function void axi_mas_agent::connect_phase(uvm_phase phase);
    `uvm_info(get_full_name(),"AXI_MAS_AGENT build_phase started",UVM_DEBUG);
    super.connect_phase(phase);
    if(axi_m_agent_config.is_active == UVM_ACTIVE)begin
      mas_drv_h.seq_item_port.connect(mas_seqr_h.seq_item_export);
      end
    else
      mas_drv_h.seq_item_port.connect(mas_seqr_h.seq_item_export);
    `uvm_info(get_full_name(),"AXI_MAS_AGENT build_phase ENDED",UVM_DEBUG);

endfunction
*/

function void axi_mas_agent::end_of_elaboration_phase(uvm_phase phase);

endfunction


function void axi_mas_agent::start_of_simulation_phase(uvm_phase phase);

endfunction


task axi_mas_agent::run_phase(uvm_phase phase);

endtask

`endif

