/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_param_mas_mon.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////



`ifndef AXI_MAS_MON_SV
`define AXI_MAS_MON_SV

class axi_mas_mon #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_monitor;
    
    `uvm_component_param_utils(axi_mas_mon #(ADDR_WIDTH,DATA_WIDTH))

    virtual axi_mas_intf #(ADDR_WIDTH,DATA_WIDTH) mas_intf;

    function new(string name = "axi_mas_mon",uvm_component parent);
        super.new(name,parent);
    endfunction

    function void build_phase(uvm_phase phase);
      //super.build_phase(phase);
    `uvm_info(get_full_name(),"AXI_MAS_MON build_phase STARTED",UVM_DEBUG);
    
    `uvm_info(get_full_name(),"AXI_MAS_MON build_phase ENDED",UVM_DEBUG);

      //if(!uvm_config_db # virtual axi_mas_intf #(`ADDR_WIDTH,`DATA_WIDTH)::get(this,"*",MON_INTF,"mon_intf"))begin
        //`uvm_info(get_type_name(),"MONITOR IS NOT GETTING");
     // end
    endfunction
  
  extern function void connect_phase(uvm_phase phase);
    extern function void end_of_elaboration_phase(uvm_phase phase);
      extern function void start_of_simulation_phase(uvm_phase phase);
  
endclass

    function void axi_mas_mon::connect_phase(uvm_phase phase);
      super.build_phase(phase);
      
    endfunction
      
      function void axi_mas_mon::end_of_elaboration_phase(uvm_phase phase);
        super.end_of_elaboration_phase(phase);
        
      endfunction
        
      function void axi_mas_mon::start_of_simulation_phase(uvm_phase phase);
        super.start_of_simulation_phase(phase);
        
      endfunction



`endif

