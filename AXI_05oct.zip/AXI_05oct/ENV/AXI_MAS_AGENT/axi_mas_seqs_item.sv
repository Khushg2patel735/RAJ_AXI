/////////////////////////////////////////////////////////////////////////
// Company		    : IndEeksha 
// Engineer		    : RAJKUMAR CHAURASIYA
// Create Date    : 23-07-2026
// Last Modifiey  : 
// File Name   	  : AXI_param_mas_seqs_item.sv
// Class Name 	  : 
// Project Name	  : 
// Description	  : 
//////////////////////////////////////////////////////////////////////////



`ifndef AXI_MAS_SEQS_ITEM_SV
`define AXI_MAS_SEQS_ITEM_SV

`include "axi_mas_define.sv"
class axi_mas_seqs_item #(parameter ADDR_WIDTH = 32,DATA_WIDTH = 32) extends uvm_sequence_item;

    typedef enum  {MAS_WRITE,MAS_READ} mas_trans_type_e;

    rand mas_trans_type_e trans_type;
   //-------write address channel----------//
    rand bit [`ID_SIZE-1 :0] AWID;
    randc bit [ADDR_WIDTH-1 :0] AWADDR;
    rand bit [`LENGTH-1 :0] AWLEN;
    rand bit [2:0]AWSIZE;
         bit [1:0] AWBURST;
   //    bit AWVALID;

    //------write data channel-----------//
    rand bit [`ID_SIZE-1 :0] WID;
    rand bit [DATA_WIDTH-1 :0] WDATA[];
    rand bit [DATA_WIDTH/8-1 :0] WSTRB;
         bit WLAST;
   //    bit WVALID;

   //------write response channel-------//
  //     bit BREADY;
    

   //------read address channel signal---//
    rand bit [`ID_SIZE-1 :0] ARID;
    rand bit [ADDR_WIDTH-1 :0] ARADDR;
    rand bit [`LENGTH-1 :0] ARLEN;
    rand bit [2:0] ARSIZE;
    rand bit [1:0] ARBURST;
      //   bit ARVALID;


   //-------read data channel signal-----//
        // bit RREADY;

    function new(string name = "axi_mas_seqs_item");
      super.new(name);
    endfunction

    constraint on_wdata_size {soft WDATA.size == AWLEN +1'b1;AWSIZE == 2;}
    constraint on_wdata_value{
        foreach(WDATA[i])
            WDATA[i] inside {[10:50]};}
   // constraint on_wlen{AWLEN == 4'h3;}
    constraint on_id{WID == AWID;}

    `uvm_object_param_utils_begin(axi_mas_seqs_item #(ADDR_WIDTH,DATA_WIDTH))
        
    `uvm_field_int(AWID,        UVM_ALL_ON)
    `uvm_field_int(AWADDR,      UVM_ALL_ON)
    `uvm_field_int(AWLEN,       UVM_ALL_ON)
    `uvm_field_int(AWSIZE,      UVM_ALL_ON)

    `uvm_field_int(WID,         UVM_ALL_ON)
    `uvm_field_array_int(WDATA, UVM_ALL_ON)
    `uvm_field_int(WSTRB,       UVM_ALL_ON)
    `uvm_field_int(WLAST,       UVM_ALL_ON)
    
    `uvm_field_int(ARID,        UVM_ALL_ON)
    `uvm_field_int(ARADDR,      UVM_ALL_ON)
    `uvm_field_int(ARLEN,       UVM_ALL_ON)
    `uvm_field_int(ARSIZE,      UVM_ALL_ON)
    `uvm_field_int(ARBURST,     UVM_ALL_ON)

    `uvm_object_utils_end


endclass
`endif




