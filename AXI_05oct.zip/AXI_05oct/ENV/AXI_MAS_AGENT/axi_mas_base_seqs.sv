`ifndef AXI_MAS_BASE_SEQS_SV
`define AXI_MAS_BASE_SEQS_SV

class axi_mas_base_seqs #(parameter ADDR_WIDTH = 32,parameter DATA_WIDTH = 32) extends uvm_sequence #(axi_mas_seqs_item #(`ADDR_WIDTH,`DATA_WIDTH));

  `uvm_object_param_utils(axi_mas_base_seqs)

    function new(string name = "axi_mas_base_seqs");
      super.new(name);
    endfunction


endclass
`endif
