
`ifndef AXI_ENV_CONFIG
`define AXI_ENV_CONFIG

class axi_env_config extends uvm_object;
  
  `uvm_object_utils(axi_env_config) 
  
  // -----------------------------------------------
  
  // has master agent.
  rand bit has_mas_agent = 1;
  
  // Number of master agent;
  rand int no_of_mas_agent = 1;
  
  // master agent config
  axi_mas_agent_config axi_m_agent_config[];
  
  // axi_master_interface
  virtual axi_mas_intf #(`ADDR_WIDTH,`DATA_WIDTH) mas_intf;
  
  // -----------------------------------------------
  
  // has slave agent.
  rand bit has_slv_agent = 1;
  
  // Number of slave agent;
  rand int no_of_slv_agent = 1;
 
  // slave agent config
  axi_slv_agent_config axi_s_agent_config[];
  
  // apb_slave_interface
  virtual axi_slv_intf #(`ADDR_WIDTH,`DATA_WIDTH) slv_intf;
  
  // -----------------------------------------------
  
  // has scoreboard.
 // rand bit has_scoreboard = 0;
  
  // has coverage.
//  rand bit has_coverage = 1;
  
  // -----------------------------------------------
  
  extern constraint no_of_s_agent;
  
  extern constraint no_of_m_agent;
  
  extern function new (string name = "axi_env_config");
    
  extern function void create_sub_config();
  
endclass
    
    
    function axi_env_config::new(string name = "axi_env_config");
      super.new(name);
    endfunction
    
function void axi_env_config::create_sub_config();
//-------------------------------------------------------------------------------------------------------

  // Creating master config
  
  axi_m_agent_config = new[no_of_mas_agent];
  
  foreach(axi_m_agent_config[i]) begin 
    // Creating master agent config.
    axi_m_agent_config[i] = axi_mas_agent_config::type_id::create($sformatf("axi_m_agent_config[%0d]",i));
    
    axi_m_agent_config[i].is_active = UVM_ACTIVE;
    
    // TODO : When we have multiple master interface. 
    axi_m_agent_config[i].mas_intf = mas_intf;
  end
 


//----------------------------------------------------------------------------------------------------------

  // Creating slave config
  axi_s_agent_config = new[no_of_slv_agent];
  
  foreach(axi_s_agent_config[i]) begin 
    // Creating slave agent config.
    axi_s_agent_config[i] = axi_slv_agent_config::type_id::create($sformatf("axi_s_agent_config[%0d]",i));
    
    axi_s_agent_config[i].is_active = UVM_ACTIVE;
    
    // TODO : When we have multiple slave interface. 
    axi_s_agent_config[i].slv_intf = slv_intf;
  end
  
endfunction
    

//consistency check to avoid wrong configuration

constraint axi_env_config::no_of_m_agent {
 has_mas_agent -> no_of_mas_agent inside {[1:10]};
 !has_mas_agent -> no_of_mas_agent == 1;
}    
    
    
constraint axi_env_config::no_of_s_agent {
 has_slv_agent -> no_of_slv_agent inside {[1:10]};
 !has_slv_agent -> no_of_slv_agent == 1;
}    
    
`endif

