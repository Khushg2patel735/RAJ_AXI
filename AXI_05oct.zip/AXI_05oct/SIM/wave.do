onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/ACLK
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/ARESETn
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWID
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWADDR
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWLEN
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWSIZE
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWVALID
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWBURST
add wave -noupdate -group MAS_AW_CHANNEL /axi_tb_top/mas_intf/AWREADY
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/mas_intf/WID
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/mas_intf/WDATA
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/mas_intf/WSTRB
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/mas_intf/WLAST
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/mas_intf/WVALID
add wave -noupdate -group MAS_W_CHANNEL /axi_tb_top/mas_intf/WREADY
add wave -noupdate -group MAS_B_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group MAS_B_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group MAS_B_CHANNEL /axi_tb_top/mas_intf/BREADY
add wave -noupdate -group MAS_B_CHANNEL /axi_tb_top/mas_intf/BID
add wave -noupdate -group MAS_B_CHANNEL /axi_tb_top/mas_intf/BRESP
add wave -noupdate -group MAS_B_CHANNEL /axi_tb_top/mas_intf/BVALID
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARID
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARADDR
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARLEN
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARSIZE
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARBURST
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARVALID
add wave -noupdate -group MAS_AR_CHANNEL /axi_tb_top/mas_intf/ARREADY
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/mas_intf/RREADY
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/mas_intf/RID
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/mas_intf/RDATA
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/mas_intf/RRESP
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/mas_intf/RLAST
add wave -noupdate -group MAS_R_CHANNEL /axi_tb_top/mas_intf/RVALID
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWID
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWADDR
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWLEN
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWSIZE
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWVALID
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWBURST
add wave -noupdate -group SLV_AW_CHANNEL /axi_tb_top/slv_intf/AWREADY
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/WID
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/WDATA
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/WSTRB
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/WLAST
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/WVALID
add wave -noupdate -group SLV_W_CHANNEL /axi_tb_top/slv_intf/WREADY
add wave -noupdate -group SLV_B_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -group SLV_B_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -group SLV_B_CHANNEL /axi_tb_top/slv_intf/BREADY
add wave -noupdate -group SLV_B_CHANNEL /axi_tb_top/slv_intf/BID
add wave -noupdate -group SLV_B_CHANNEL /axi_tb_top/slv_intf/BRESP
add wave -noupdate -group SLV_B_CHANNEL /axi_tb_top/slv_intf/BVALID
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARVALID
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARREADY
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARID
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARADDR
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARLEN
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARSIZE
add wave -noupdate -expand -group SLV_AR_CHANNEL /axi_tb_top/slv_intf/ARBURST
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/ACLK
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/ARESETn
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/RVALID
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/RREADY
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/RID
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/RDATA
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/RRESP
add wave -noupdate -expand -group SLV_R_CHANNEL /axi_tb_top/slv_intf/RLAST
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {55 ns} 0}
quietly wave cursor active 1
configure wave -namecolwidth 200
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {528 ns} {714 ns}
